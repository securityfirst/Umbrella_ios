---
index: 7
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[被跟蹤-初學者課程](umbrella://work/being-followed/beginner)中了解固定位置的反監控。

在[被跟蹤-進階課程](umbrella://work/being-followed/advanced)中了解當你在步行時如何進行反監控。

### 相關課程與工具

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [聚會](umbrella://work/meetings)
*   [車輛](umbrella://travel/vehicles)
*   [管理資訊課程](umbrella://information/managing-information)
*   [手機課程](umbrella://communications/mobile-phones/beginner)