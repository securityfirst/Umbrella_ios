---
index: 1
title: 在車輛中的監控
---
反監視是檢測和減輕敵對監視的過程。

（在[被跟蹤-初學者課程](umbrella://work/being-followed/beginner)中了解更多相關信息。）

本課程涵蓋了在車輛中的監控。

[被跟蹤](umbrella://work/being-followed/advanced) 涉及到步行監視。
![圖像](surveillance4.png)