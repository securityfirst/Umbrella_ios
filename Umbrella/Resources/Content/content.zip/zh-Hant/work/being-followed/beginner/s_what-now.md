---
index: 4
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[被跟蹤-進階課程](umbrella://work/being-followed/advanced)中了解當你在步行時如何進行反監控。

在[被跟踪-專家課程](umbrella://work/being-followed/expert)中了解如何在車輛中進行反監控。