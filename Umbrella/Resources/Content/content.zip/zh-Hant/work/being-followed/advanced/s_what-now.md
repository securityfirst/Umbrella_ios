---
index: 10
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[被跟蹤-初學者課程](umbrella://work/being-followed/beginner)中了解固定位置的反監控。

在[被跟蹤-專家課程](umbrella://work/being-followed/expert)中了解車輛中的反監控。

### 相關課程

*   [聚會](umbrella://work/meetings)
*   [車輛](umbrella://travel/vehicles)
*   [邊界](umbrella://travel/borders)