---
index: 1
title: 對抗實體監控
---
反監視是檢測和減輕敵對監視的過程。

（在[跟隨-初學者課程](umbrella://work/being-followed/beginner)中了解更多相關信息。）

本課涉及徒步監視。

[被跟踪-專家課程](umbrella://work/being-followed/expert)涉及了人們在車輛的監控。。

![圖像](surveillance2.png)