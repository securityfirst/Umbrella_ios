---
index: 5
title: 現在怎樣？
---
滑動右側到課程檢查表。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [在線濫用](umbrella://communications/online-abuse)
*   [保護您的工作區](umbrella://information/protect-your-workspace)