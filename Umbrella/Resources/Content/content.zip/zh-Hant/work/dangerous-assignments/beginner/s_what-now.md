---
index: 4
title: 現在怎樣？
---
滑動右側到課程檢查表。

在[危險任務-進階課程](umbrella://work/dangerous-assignments/advanced)中了解前往犯罪現場的信息。

### 相關課程與工具

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [做好準備](umbrella://travel/preparation)
*   [手機](umbrella://communications/mobile-phones)
*   [車輛](umbrella://travel/vehicles)
*   [無線電和衛星電話](umbrella://communications/radios-and-satellite-phones)