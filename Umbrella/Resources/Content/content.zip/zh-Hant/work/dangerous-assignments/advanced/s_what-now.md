---
index: 4
title: 現在怎樣？
---
滑動右側到課程檢查表。

### 相關課程與工具

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [被跟蹤](umbrella://work/being-followed/beginner)
*   [綁架](umbrella://incident-response/kidnapping/beginner)