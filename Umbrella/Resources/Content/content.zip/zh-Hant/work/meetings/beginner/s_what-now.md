---
index: 8
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [被跟蹤](umbrella://work/being-followed/beginner)
*   [手機](umbrella://communications/mobile-phones)
*   [電子郵件課程](umbrella://communications/email)
*   [車輛](umbrella://travel/vehicles)
*   [邊界](umbrella://travel/borders)