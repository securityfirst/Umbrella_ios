---
index: 1
title: 風險
---
會議可能：

*   透露參與者的身份;
*   揭露參與者的工作;
*   觸發綁架或逮捕等嚴重事件。

（了解關於[綁架](umbrella://incident-response/kidnapping/beginner)和[逮捕](umbrella://incident-response/arrests)的更多信息。）

與危險人群一起規劃和準備敏感會議至關重要。