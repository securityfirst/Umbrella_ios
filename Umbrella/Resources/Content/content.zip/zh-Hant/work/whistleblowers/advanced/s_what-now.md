---
index: 4
title: 現在怎樣？
---
滑動右側到課程檢查表。

在[告密者-初學者課程](umbrella://work/whistleblowers/beginner)中了解如何以告密者的身份發送信息。

### 相關課程與工具

* [安全性規劃](umbrella://assess-your-risk/security-planning)
* [管理資訊課程](umbrella://information/managing-information/beginner)
* [保護檔案課程](umbrella://information/protecting-files)
* [在線隱私](umbrella://communications/online-privacy/advanced)
* [發送消息](umbrella://communications/sending-a-message)
* [電子郵件課程](umbrella://communications/email)