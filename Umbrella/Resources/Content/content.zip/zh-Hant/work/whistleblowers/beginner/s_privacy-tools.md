---
index: 4
title: 隱私工具
---
### 加密文件並匿名通信以保護您的身份。

（了解有關[保護文件](umbrella://information/protecting-files)的更多信息。）

## Secure Drop 

Secure Drop是免費的開源軟件，您可以使用該軟件匿名地向媒體機構和非政府組織提交信息。可以在
[https://securedrop.org/directory/]
(https://securedrop.org/directory/)
上找到使用Secure Drop的列表或組織。

通過Tor訪問Secure Drop以確保您匿名使用它。

（在[在線隱私](umbrella://communications/online-privacy/advanced)課程中了解有關此內容的更多信息。）

## 安全通信

一些安全信使附加到電話號碼或帳戶，這可能足以揭示您正在與誰通信，即使您說的是加密的。

如果您所涉及的潛在對手包括政府或情報機構，請考慮使用[Ricochet.im](https://ricochet.im/)。它是免費的開源軟件，允許您使用唯一的地址而不是用戶名通過Tor網絡交換端到端的加密消息。

（了解有關[發送消息](umbrella://communications/sending-a-message)的更多信息。）