---
index: 5
title: 現在怎樣？
---
滑動右側到課程檢查表。

在[告密者-進階課程](umbrella://work/whistleblowers/advanced)中了解保護來源和告密者。

### 相關課程與工具

* [安全性規劃](umbrella://assess-your-risk/security-planning)
* [管理資訊](umbrella://information/managing-information/beginner)
* [保護檔案](umbrella://information/protecting-files)
* [在線隱私](umbrella://communications/online-privacy/advanced)
* [發送消息](umbrella://communications/sending-a-message)
* [電子郵件](umbrella://communications/email)