---
index: 4
title: 瑞波幣
---
# 瑞波幣

[Ripple](https://play.google.com/store/apps/details?id=info.guardianproject.ripple&hl=en)是一款免費的開源Android應用，可告知其他應用程序在緊急情況下應採取哪些措施。

例如，如果您觸發Ripple，Umbrella將變成計算器，這樣任何人都無法訪問您的安保諮詢意見，表單和清單。 （搖動手機取消屏蔽。）

如果您知道自己的設備即將被查獲，請點按“瑞波幣”圖標以觸發其他集成應用程序以更改其操作方式。

![圖像](ripple0.png)

瑞波幣將告訴您它可以觸發哪些應用程序。

![圖像](ripple1.png)

_Ripple處於BETA或測試模式._