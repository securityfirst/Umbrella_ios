---
index: 4
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[抗議-進階課程](umbrella://work/protests/advanced)中了解參加抗議活動的相關信息。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [防護裝備](umbrella://travel/protective-equipment)