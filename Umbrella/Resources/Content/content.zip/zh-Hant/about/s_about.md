---
index: 1
title: 關於
---
## 你好！

Umbrella是由Security First建立的一款開源工具 - 一家位於倫敦肖爾迪奇的小型非政府組織。在我們與世界各地的高風險活動家合作的這些年來，我們意識到使安全更容易和更容易獲得的需求 - 所以我們決定走到一起，為此做點東西。

Security First還為活動家，記者和援助工作者提供實體和數位安全培訓。我們的課程涵蓋所有內容，無論是從發送安全電子郵件到進行物理反監視以及處理敏感信息來源等。我們培訓每個領域的人，無論是從大型非政府組織的人員到高風險個人活動家。

要了解更多信息，以任何方式（代碼，資金或內容）做出貢獻，或者只是讓我們知道您的想法，請訪問我們的[網站](https://secfirst.org)或發送電子郵件至info@secfirst.org。歡迎所有評論和批評 - 它們會讓我們變得更好！

我們的團隊：

*   Rok Biderman  - >構建事物
*   Rory Byrne  - >保護事物
*   Alex Guerrieri  - > 推薦事物
*   Holly Kilroy  - >編寫文章
*   Vesna Planko  - >設計事物

過去的朋友正在研究新事物：
*   Mitesh Patel  - >改進事物
*   Adam Schakaki  - >固定事物

[執照](umbrella://licences/)  
[謝謝](umbrella://thankyou/)