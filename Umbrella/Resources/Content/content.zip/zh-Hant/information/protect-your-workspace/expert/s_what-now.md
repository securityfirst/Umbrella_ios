---
index: 3
title: 現在怎樣?
---
滑動右側到課程檢查表。

[工作區-進階課程](umbrella://information/protect-your-workspace/advanced)告訴您如何保護敏感信息以防止入侵者訪問。

[工作區-專家課程](umbrella://information/protect-your-workspace/expert)告訴您如何保護您的設備免受實體威脅。

### 來源

* Security in a Box，[保護您的信息免受實體威脅](https://securityinabox.org/en/guide/physical/)，更新於2018年6月28日。

### 進一步閱讀

- Tactical Tech, [整體安全手冊](https://holistic-security.tacticaltech.org) ([pdf](https://holistic-security.tacticaltech.org/downloads.html)); [整體培訓師手冊](https://holistic-security.tacticaltech.org/trainers-manual.html) ([pdf](https://holistic-security.tacticaltech.org/ckeditor_assets/attachments/60/holisticsecurity_trainersmanual.pdf)).