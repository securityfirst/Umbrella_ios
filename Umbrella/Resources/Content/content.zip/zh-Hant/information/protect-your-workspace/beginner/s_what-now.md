---
index: 6
title: 現在怎樣?
---
滑動右側到課程檢查表。

[工作區-進階課程](umbrella://information/protect-your-workspace/advanced)告訴您如何保護敏感信息，以防止入侵者的訪問。

[工作區-專家課程](umbrella://information/protect-your-workspace/expert)告訴您如何保護您的設備免受物理威脅。

### 相關課程與工具

*   [安全性規劃](umbrella://assess-your-risk/security-planning)

### 來源

* Security in a Box，[保護您的信息免受物理威脅](https://securityinabox.org/en/guide/physical/)，更新於2018年6月28日。

### 進一步閱讀

- 前線衛士，[安全工作手冊](https://www.frontlinedefenders.org/en/resource-publication/workbook-security-practical-steps-human-rights-defenders-risk)。