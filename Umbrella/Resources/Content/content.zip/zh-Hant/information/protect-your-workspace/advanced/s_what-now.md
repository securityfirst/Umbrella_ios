---
index: 6
title: 現在怎樣?
---
滑動右側到課程檢查表。

[工作區-初學者課程](umbrella://information/protect-your-workspace/beginner)告訴您如何評估您的工作環境並計劃保護它。

[工作區-專家課程]（(umbrella://information/protect-your-workspace/expert)告訴您如何保護您的設備免受實體威脅。

### 來源

* Security in a Box，[保護您的信息免受實體威脅](https://securityinabox.org/en/guide/physical/)，更新於2018年6月28日。