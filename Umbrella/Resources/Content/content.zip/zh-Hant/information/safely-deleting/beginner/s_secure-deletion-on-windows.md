---
index: 2
title: Windows上的安全刪除
---
# Bleachbit

Bleachbit是一款適用於Windows的免費開源安全刪除工具。它比內置選項好得多。

從官方網站上[下載](http://bleachbit.sourceforge.net/download/windows)它並保存文件。雙擊已下載的文件進行安裝。

## 要安全刪除單個文件或文件夾：

*    單擊“文件”功能表，然後選擇“碎化文件”或“碎化文件夾”。

## 要安全刪除舊數據：

*   單擊“文件”菜單，然後選擇“擦除可用空間”。

這將嘗試通過使用隨機數據覆蓋硬盤驅動器的所謂空白部分來刪除已刪除的任何文件痕跡。這個過程可能需要花上一段時間。

文檔可在[此處](https://docs.bleachbit.org/)獲得。