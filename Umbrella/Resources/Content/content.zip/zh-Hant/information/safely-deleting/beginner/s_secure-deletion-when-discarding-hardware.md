---
index: 5
title: 丟棄硬體前作好安全刪除
---
# 擦拭硬盤

在將計算機扔掉，在eBay上出售或將舊機器藏在壁櫥中之前擦拭硬盤。

像[DBAN](https://dban.org/)這樣的工具使這很容易。有關如何在網絡上使用它的各種教程，(包括[這裡](https://www.lifewire.com/how-to-erase-a-hard-drive-using-dban-2619148)) 。

# 撕碎CD-ROMS

撕碎CD-ROM，就像你使用的紙張一樣。

有便宜的碎紙機會咀嚼CD-ROM。除非你完全確定沒有任何敏感信息，否則永遠不要把垃圾扔進垃圾箱。

# 加密SSD，USB閃存驅動器和SD卡

在這些格式中，安全刪除即使不是不可能，也很困難。

使用加密，即使文件仍在磁盤上，對於沒有密鑰解密的人來說，它至少看起來像胡言亂語。

（了解有關[保護文件](umbrella://information/protecting-files)的更多信息。）