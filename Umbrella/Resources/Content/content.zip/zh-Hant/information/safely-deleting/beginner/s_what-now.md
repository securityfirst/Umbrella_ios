---
index: 6
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程/工具

*   [保護文件](umbrella://information/protecting-files)

### 進一步閱讀

*   EFF, 監視防衛, 如何從 [Linux](https://ssd.eff.org/en/module/how-delete-your-data-securely-linux), [Mac OS](https://ssd.eff.org/en/module/how-delete-your-data-securely-mac-os-x), a和 [Windows](https://ssd.eff.org/en/module/how-delete-your-data-securely-windows)刪除您的數據. 
*   Security in a Box, [破壞敏感信息](https://securityinabox.org/en/guide/destroy-sensitive-information/).