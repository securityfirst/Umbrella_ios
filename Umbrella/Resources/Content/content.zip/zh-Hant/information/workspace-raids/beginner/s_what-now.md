---
index: 5
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [保護您的工作區](umbrella://information/protect-your-workspace)
*   [備份課程](umbrella://information/backing-up)
*   [安全刪除課程](umbrella://information/safely-deleting)
*   [保護檔案課程](umbrella://information/protecting-files)