---
index: 5
title: 備份軟件
---
# Cobian Backup

Cobian Backup是一個方便使用的工具，可以：

*   自動運行;
*   按預定時間間隔;
*   僅包括自上次備份以來已更改的文件;
*   壓縮備份以使其更小。

了解如何安裝和運行[Cobian Backup](umbrella://tools/files/s_cobian-backup.md)。