---
index: 9
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程與工具

*   [保護文件](umbrella://information/protecting-files)
*   [安全刪除](umbrella://information/safely-deleting)
*   [VeraCrypt](umbrella://tools/files/s_veracrypt.md)
*   [Cobian Backup](umbrella://tools/files/s_cobian-backup.md)
*   [Recuva工具](umbrella://tools/files/s_recuva.md)

### 進一步閱讀

*   Security in a Box, [保護計算機上的敏感文件](https://securityinabox.org/en/guide/secure-file-storage/).