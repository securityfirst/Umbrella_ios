---
index: 3
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[密碼-初學者課程](umbrella://information/passwords/beginner)中了解如何創建高強度密碼。

在[密碼-進階課程](umbrella://information/passwords/advanced)中了解如何管理您的密碼。

### 相關課程與工具

*   [保護檔案](umbrella://information/protecting-files)
*   [準備](umbrella://travel/preparation) 

### 進階閱讀

*   EFF，[美國邊境的數字隱私：保護您設備上的數據](https://www.eff.org/wp/digital-privacy-us-border-2017)