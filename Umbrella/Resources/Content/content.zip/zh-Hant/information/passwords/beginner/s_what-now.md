---
index: 5
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[密碼-進階課程](umbrella://information/passwords/advanced)中了解如何管理密碼

到專家課程了解萬一你被迫交出密碼時可以採取的措施
[專家課程](umbrella://information/passwords/expert)

### 進一步閱讀

* Security First，[安全密碼和數據加密](https://advocacyassembly.org/en/courses/31/#/chapter/1/lesson/1)，Advocacy Assembly的免費在線培訓。