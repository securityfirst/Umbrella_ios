---
index: 3
title: 記住安全密碼
---
## 一些技巧將幫助您創建輕易讓您記起但難以猜測的密碼。

*   **對大寫字母的位置做出調整:**'My naME is Not MR. MarSter'

*   **更改數字和字母：**'a11 w0Rk 4nD N0 p14Y'

*   **合併符號:**'c@t(heR1nthery3'

*   **使用多種語言：**'Let Them Eat 1e gateaU au ch()colaT''

*   **使用首字母縮略詞：**'Are you happy today?' 變成 'rU:-)2d@y?'

（在[密碼-進階課程](umbrella://information/passwords/advanced)中了解[KeePassXC](umbrella://tools/encryption/s_keepassxc.md)等安全密碼數據庫。