---
index: 4
title: 隱藏你的加密
---
# 偽裝VeraCrypt

## 如果您擔心在您的設備上找到加密軟件：

*   將加密卷命名為不同類型的文件。

> *例如：添加'.iso'文件擴展名使700 MB左右的卷看起來像CD圖像。對於較小的卷，其他擴展更為實際。*

*   使用便攜版VeraCrypt，而不是將其安裝在您的計算機上。（即使在便攜模式下，VeraCrypt也可能留下痕跡，表明它已在您的設備上使用過。）

在[VeraCrypt](umbrella://tools/files/s_veracrypt.md)工具指南中了解更多信息。