---
index: 6
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程與工具

*   [管理資訊課程](umbrella://information/managing-information)
*   [惡意軟體](umbrella://information/malware)
*   [密碼](umbrella://information/passwords/beginner)
*   [VeraCrypt ](umbrella://tools/files/s_veracrypt.md)

### 進一步閱讀

*   Security First，[安全密碼和數據加密](https://advocacyassembly.org/en/courses/31/#/chapter/1/lesson/1)，在Advocacy Assembly上的免費在線培訓。
*   EFF，監視自衛，[加密](https://ssd.eff.org/en/module/what-encryption)
*   全球合作夥伴數字化，[加密法律和政策的世界地圖](https://www.gp-digital.org/world-map-of-encryption/)