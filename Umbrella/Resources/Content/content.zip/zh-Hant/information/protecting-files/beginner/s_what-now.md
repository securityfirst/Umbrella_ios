---
index: 7
title: 現在怎樣?
---
滑動右側到課程檢查表

在[保護文件-進階課程](umbrella://information/protecting-files/advanced)中了解如何加密文件。）

### 相關課程與工具

*   [備份](umbrella://information/backing-up)
*   [密碼](umbrella://information/passwords)
*   [手機](umbrella://communications/mobile-phones/beginner)
*   [惡意軟體](umbrella://information/malware)
*   [互聯網進階課程](umbrella://communications/the-internet/advanced)
*   適用於[Windows](umbrella://tools/tor/s_tor-for-windows.md)，[Mac](umbrella://tools/tor/s_tor-for-mac-os-x.md), 和 [Linux](umbrella://tools/tor/s_tor-for-linux.md)的Tor。
*   [加密你的iPhone](umbrella://tools/encryption/s_encrypt-your-iphone.md)
*   [安卓手機的基本安全設定](umbrella://tools/other/s_android.md)

### 來源

*   EFF，安全自衛，[安全保存您的數據](https://ssd.eff.org/en/module/keeping-your-data-safe)，最後審查日期為2018年11月2日。