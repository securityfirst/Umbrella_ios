---
index: 4
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程

*   [安全刪除](umbrella://information/safely-deleting)

### 進一步閱讀

*   EFF，監視防衛， ["評估您的風險"]
(https://ssd.eff.org/en/module/assessing-your-risks)。