---
index: 1
title: 綁架階段
---
綁架策略基於：

*   躲避
*   生存。

綁架有五個階段：

### 1. 監視

### 2. 捕獲

### 3. 運輸（一次或多次）

### 4. 監禁

### 5. 釋放或終止

## 躲避

在綁架初學者課程中概述了如何規避監視和捕獲的相關信息。

## 生存

[綁架-進階課程](umbrella://incident-response/kidnapping/advanced)概述了捕獲，運輸，監禁和釋放的生存策略。

[綁架-專家課程](umbrella://incident-response/kidnapping/expert)概述了一名同事被綁架時的事件管理。