---
index: 5
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[恐怖主義-初學者課程](umbrella://incident-response/terrorism/beginner)中了解評估風險的相關信息。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [保護您的工作區](umbrella://information/protect-your-workspace)
*   [被跟蹤](umbrella://work/being-followed/beginner)
*   [公共傳播](umbrella://work/public-communications)