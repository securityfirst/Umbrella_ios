---
index: 5
title: 現在怎樣?
---
滑動右側到課程檢查表。

在[恐怖襲擊事件-進階課程](umbrella://incident-response/terrorism/advanced)中了解在恐怖襲擊期間應該採取的措施。

### 相關課程

*   [安全性規劃](umbrella://assess-your-risk/security-planning)
*   [保護您的工作區](umbrella://information/protect-your-workspace)
*   [被跟蹤](umbrella://work/being-followed/beginner)
*   [公共傳播](umbrella://work/public-communications)