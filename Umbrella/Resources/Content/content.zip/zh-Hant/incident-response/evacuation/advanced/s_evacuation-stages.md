---
index: 1
title: 撤離階段
---
## 疏散有四個階段

### 1. 規劃

### 2.警報

### 3. 疏散前

### 4. 撤離

[疏散-初學者課程](umbrella://incident-response/evacuation/beginner)概述了計劃和警報的相關信息。

本課程概述了撤離前和撤離的相關信息。