---
index: 1
title: 如果你被毆打
---
### 性侵犯是一種特殊的威脅類型，需要預防，緩解，危機管理和後續護理。

[性侵犯-初學者課程](umbrella://incident-response/sexual-assault/beginner)概述了相應的預防措施。

本課程概述了當你遭到強姦或毆打時應採取的措施。

[性侵犯-專家課程](umbrella://incident-response/sexual-assault/expert)概述了當團隊成員被強姦或毆打時該採取的措施。