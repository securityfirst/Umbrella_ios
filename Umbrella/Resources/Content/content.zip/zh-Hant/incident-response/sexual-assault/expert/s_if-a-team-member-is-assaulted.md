---
index: 1
title: 如果團隊成員遭到攻擊
---
本課程概述了團隊成員遭到強姦或毆打時應採取的措施。

在遭到性侵犯和強姦後，有四件事需要謹慎管理：

*   醫療保健;
*  心理輔導;
*  法律訴訟
*  保密。

確保制定相應的程序以尊重和保護受害者
的機密，法律權力和人權，隱私和尊嚴。

[性侵犯-初學者課程](umbrella://incident-response/sexual-assault/beginner)概述了預防的相關信息。

[性侵犯-進階課程](umbrella://incident-response/sexual-assault/advanced)概述在你被強姦或毆打時應該要採取的措施。