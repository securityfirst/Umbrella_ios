---
index: 126
title: VeraCrypt
---
# VeraCrypt

一套開源自由的檔案加密工具可讓人安全地儲存敏感資訊。 