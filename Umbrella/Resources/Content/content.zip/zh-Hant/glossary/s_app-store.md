---
index: 7
title: 應用程式商店
---
# App Store應用程式商店

可尋找與下載 iPhone 應用程式的預設資源庫。 