---
index: 39
title: Firefox
---
# Firefox

一個流行的開源網頁瀏覽器可作為替代微軟Internet Explorer的另一種選項