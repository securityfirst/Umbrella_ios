---
title: 網域名
---
# 網域名

就是一般常稱的互聯網上網站的網址，例如：www.google.com