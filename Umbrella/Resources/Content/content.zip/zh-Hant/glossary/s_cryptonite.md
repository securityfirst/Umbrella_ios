---
title: Cryptonite
---

** Cryptonite **：用於Android智能手機上文件加密的FOSS應用程序。