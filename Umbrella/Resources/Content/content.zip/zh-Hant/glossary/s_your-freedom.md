---
index: 135
title: Your-Freedom
---
# Your-Freedom

一套免費的工具利用連上私有代理來躲開過濾審查。如果Your-Freedom設定適當，這些代理連線受到加密以保證通訊的私密安全。