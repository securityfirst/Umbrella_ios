---
title: 關於
---
在Umbrella APP的課程中所使用的技術用語辭彚，其定義如下：