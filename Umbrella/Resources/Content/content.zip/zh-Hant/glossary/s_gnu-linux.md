---
index: 46
title: GNU/Linux
---
# GNU/Linux

開源免費的作業系統，以作為微軟Windows系統之外的另類替代選項