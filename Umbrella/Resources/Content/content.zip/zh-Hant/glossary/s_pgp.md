---
title: PGP
---
# PGP

PGP 或全名 Pretty Good Privacy 是初次運作公鑰密碼的産物之一。它的作者，Phil Zimmermann, 於 1991 發表這套程式來協助其它社會運動人士等人來保護自己的通訊安全。當這套程式傳佈到國外後，美國政府曾正式地調查 Phil Zimmermann。當年，出口有關公鑰加密技術是違反了美國法令。. PGP 繼續以商用軟體産品存在，而利用 PGP 基本標準來執行的自由l軟體版本則是 GnuPG (or GPG) 。因為這二個用法常常互用互換，人們即便使用的是GnuPG，仍習慣用 "PGP 金鑰 " 或 "PGP 訊息"等說法。