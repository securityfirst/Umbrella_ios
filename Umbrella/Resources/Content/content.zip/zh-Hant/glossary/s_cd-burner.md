---
index: 17
title: CD刻錄機
---
# CD刻錄機

一個電腦的CD-ROM 磁碟機可以在空白光碟片寫入資料。DVD 燒錄器同理可處理空白DVDs光碟。CD-RW *和 *DVD-RW 磁碟機則可以在同一張CD-RW or DVD-RW 光碟上刪除或覆寫多次。