---
title: 基本輸入/輸出系統（BIOS）
---
# Basic Input/Output System (BIOS)

BIOS 是電腦上第一個與最深底層的軟體。BIOS 可讓你設定許多與電腦硬體相關的進階偏好，包括啟動密碼。