---
title: 黑莓機
---
# 黑莓機BlackBerry

一種運行黑莓作業系統的的智慧型手機，其由Research In Motion (RIM)所開發。