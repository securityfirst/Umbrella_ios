---
index: 6
title: .apk file
---
# .apk file

安卓智慧手機上的應用程式所使用的副檔名。 