---
index: 69
title: LiveCD 自生系統
---
# LiveCD 自生系統

可讓使用者透過CD來讓電腦暫時地執行不同的作業系統