---
title: XMPP
---
# XMPP

網路即時通訊的開放標準 - Google 使用 XMPP 作為其聊天軟體Google Chat; Facebook 一度曾提供此套通訊標準後來停止了。非企業公司的獨立即時通訊服務通常會採用XMPP。而像WhatsApp 這類的服務則有他們自己封閉商業祕密的協議。