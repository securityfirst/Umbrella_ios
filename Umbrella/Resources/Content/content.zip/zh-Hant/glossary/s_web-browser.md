---
title: 網頁瀏覧器
---
# 網頁瀏覽器

用來觀看網站的應用程式，如 Firefox, Safari, Internet Explorer ,Chrome  都是網頁瀏覽器，而智慧手機內置的網頁瀏覽器也是為了相同的目的。