---
title: Obscuracam工具
---
# Obscuracam工具

Android 手機上的自由軟體應用，可以模糊照片中的人臉以保護人們的身份。