---
title: Thunderbird 非正式中文名稱為雷鳥
---
# Thunderbird 非正式中文名稱為雷鳥

FOSS電子郵件程序，具有許多安全功能，包括對Enigmail加密附加組件的支持