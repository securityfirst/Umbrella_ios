---
index: 80
title: 作業系統
---
# 作業系統

一套在電腦上執行所有程序的程序，如 Windows, Android and Apple's OS X 與 iOS 都是作業系統的例子。