---
title: Master password
---
# Master password

一個用來解鎖儲存其它密碼儲存或其它解開程式、訊息的密碼，最好盡量讓主密碼的強度高一點。 