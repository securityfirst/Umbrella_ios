---
title: Cobian Backup 工具
---
# Cobian Backup工具

開源免費的備份工具。最新版的Cobian 變成了閉源的免費軟體，但之前的版本仍然是以 FOSS形式發佈。