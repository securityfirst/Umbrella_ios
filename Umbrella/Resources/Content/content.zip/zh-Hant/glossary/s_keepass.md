---
title: KeePassXC
---
# KeePassXC

免費的安全密碼資料庫