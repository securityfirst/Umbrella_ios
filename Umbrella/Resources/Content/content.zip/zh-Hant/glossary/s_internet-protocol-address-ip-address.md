---
index: 55
title: 網路協議地址 (IP address)
---
# 互聯網協議地址 (IP address)

當你的電腦連上互聯網時，所被分派到的一個獨一無二的辨別位址。