---
title: Windows 手機
---
# Windows Phone

由微軟開發的智能手機操作系統