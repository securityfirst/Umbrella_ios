---
title: BleachBit
---
# BleachBit

一款可以安全並永久刪除計算機或可移動存儲設備信息的工具。