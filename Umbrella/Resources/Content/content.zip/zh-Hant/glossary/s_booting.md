---
index: 15
title: 開機啟動
---
# Booting開機啟動

開啟電腦的動作