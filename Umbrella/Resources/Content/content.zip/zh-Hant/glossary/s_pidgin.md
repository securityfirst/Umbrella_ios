---
index: 89
title: Pidgin
---
# Pidgin

FOSS的即時通訊工具，可支援加密外掛 Off the Record (OTR)