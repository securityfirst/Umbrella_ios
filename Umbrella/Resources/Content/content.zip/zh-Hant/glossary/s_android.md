---
title: 安卓
---
# Android 安卓

由Google開發的基於Linux的智能手機和平板電腦設備開源操作系統。