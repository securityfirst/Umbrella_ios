---
title: Java 應用程式 (Applets)
---
# Java 應用程式 (Applets)

小型工具程式可以跨平台地執行於多種作業系統下，通常用來改善網頁的功能。