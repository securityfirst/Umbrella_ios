---
title: HTTPS
---
# HTTPS

我們所孰悉的網址模樣："http://www.example.com/", 可以認出 "http" 這個字眼。HTTP (hypertext transfer protocol 超文本傳輸協定) 是電腦上的網頁瀏覽器和遠端網頁伺服器之間通話的方式。不幸的是，標準的http 在互聯網上僅能不安全地傳送明文。 HTTPS ( S 代表「安全」 "secure")則採用加密法能更佳地保護傳送到網站上以及回收到的資料。