---
index: 36
title: F-Droid
---
# F-Droid

是另一套供同各手機應用程式下載的資源庫，其上供應許多開源免費的應用軟體。