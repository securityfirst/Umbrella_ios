---
title: NoScript工具
---
# NoScript工具

Firefox瀏覽器上的安全插件用來保護您免受可能存在於不熟悉的網頁中的惡意程序的侵害