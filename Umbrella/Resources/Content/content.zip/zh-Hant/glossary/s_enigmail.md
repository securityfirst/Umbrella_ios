---
title: Enigmail
---
# Enigmail

Thunderbird 電子郵件軟體的附加元件，可以用來傳送與接收加密郵件與進行郵件數位簽署。 