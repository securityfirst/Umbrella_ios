---
index: 31
title: EDGE, GPRS, UMTS
---
# EDGE, GPRS, UMTS

GSM增強數據率演進 EDGE, 通用封包無線服務 GPRS, 通用行動通訊系統UMTS - 這些技術都可讓行動設備連上互聯網。