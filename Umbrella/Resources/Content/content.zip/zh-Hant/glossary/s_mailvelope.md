---
index: 70
title: Mailvelope
---
# Mailvelope


Mailvelope是一個免費的開源瀏覽器擴展，允許您在使用Webmail服務時發送和接收加密的電子郵件文本和附件。 它依賴於與GnuPG和PGP相同的公鑰加密形式。