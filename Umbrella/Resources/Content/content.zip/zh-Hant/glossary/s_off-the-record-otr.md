---
index: 78
title: 不留記錄 (OTR)
---
# 不留記錄 (OTR)

即時通訊系統往往未經加密， OTR 則是對它們的一種加密方式，讓用戶可以繼續使用熟悉的網路如Facebook chat、 Google Chat 、 Hangouts、 Microsoft Messenger 但讓這些即時通訊更能抵抗監控。