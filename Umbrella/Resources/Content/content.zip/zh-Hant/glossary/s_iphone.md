---
title: iPhone
---
# iPhone

蘋果電腦所設計的一款智慧手機品牌，其仍執行Apple's iOS 作業系統。