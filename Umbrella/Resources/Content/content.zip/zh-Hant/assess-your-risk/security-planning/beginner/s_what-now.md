---
index: 10
title: 現在怎樣?
---
滑動右側到課程檢查表。

### 相關課程與工具

*   [管理資訊課程](umbrella://information/managing-information)
*   [旅行準備](umbrella://information/backing-up)
*   [保護您的工作區](umbrella://information/protect-your-workspace)
*   [安全刪除課程](umbrella://information/backing-up)
*   [撒離](umbrella://incident-response/evacuation)
*   [逮捕](umbrella://incident-response/arrests)
*   [綁架](umbrella://incident-response/kidnapping)
*   [性侵犯](umbrella://incident-response/sexual-assault)

### 來源

* 前線衛士，[安全工作手冊：面臨風險的人權維護者的實際步驟](https://www.frontlinedefenders.org/en/resource-publication/workbook-security-practical-steps-human-rights-defenders-risk) ，2016年6月23日。
*  國際保護，[新的人權維護者保護手冊](https://www.protectioninternational.org/en/node/1106)。