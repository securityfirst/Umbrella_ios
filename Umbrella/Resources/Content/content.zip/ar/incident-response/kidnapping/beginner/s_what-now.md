---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعلم أساليب البقاء على قيد الحياة إذا تم اختطافك في [Kidnapping Advanced]من  (umbrella://incident-response/kidnapping/advanced).

تعرف على ما يجب فعله إذا تم اختطاف أحد الموظفين في [خبير الاختطاف](umbrella://incident-response/kidnapping/expert).

### الدروس ذات الصلة / الأدوات

*   [الاخلاء](umbrella://incident-response/evacuation)
*   [مركبة](umbrella://travel/vehicles)
*   [يجري متابعتها](umbrella://work/being-followed/beginner)
*   [الاعتداء الجنسي](umbrella://incident-response/sexual-assault)
*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)

### مصادر

*   منظمة كير الدولية ، [دليل السلامة والأمن](https://www.eisf.eu/wp-content/uploads/2014/09/0614-Macpherson-2004-CARE-International-Safety-and-Security-Handbook.pdf) .
*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).
*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu] من (https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   منظمة الحماية الدولية ، [دليل الحماية الجديد للمدافعين عن حقوق الإنسان] من (https://www.protectioninternational.org/en/node/1106).