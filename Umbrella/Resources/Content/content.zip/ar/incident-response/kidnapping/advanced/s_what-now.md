---
index: 7
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعلم كيفية تجنب الاختطاف في [اختطاف المبتدئين](umbrella://incident-response/kidnapping/beginner).

تعرف على ما يجب فعله إذا تم اختطاف أحد الموظفين في [خبير الاختطاف](umbrella://incident-response/kidnapping/expert).

### مصادر

*   منظمة كير الدولية ، [دليل السلامة والأمن](https://www.eisf.eu/wp-content/uploads/2014/09/0614-Macpherson-2004-CARE-International-Safety-and-Security-Handbook.pdf) .
*   [الحماية الدولية: دليل جديد للحماية للمدافعين عن حقوق الإنسان (الطبعة الثالثة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).
*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu](https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   منظمة الحماية الدولية ، [دليل الحماية الجديد للمدافعين عن حقوق الإنسان](https://www.protectioninternational.org/en/node/1106).

### قراءة متعمقة

*   جود تيبوت ، [حياة بعد الأسر: دليل إعادة الإدماج](http://hostageuk.org/wp-content/uploads/2016/08/ReintegrationGuide_web.pdf) ، المملكة المتحدة للرهائن ، 2016.