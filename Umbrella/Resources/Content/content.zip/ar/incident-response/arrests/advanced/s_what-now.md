---
index: 4
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرّف على ما يجب فعله إذا تم القبض عليك في [المبتدئين في التوقيفات]((umbrella://incident-response/arrests/beginner).

### الدروس ذات الصلة / الأدوات

*   [دعم الطوارئ](umbrella://emergency-support)
*  [تحضير](umbrella://travel/preparation)
*   [الاحتجاجات](umbrella://work/protests/advanced)
* [الاعتداء الجنسي](umbrella://incident-response/sexual-assault/expert)

### مصادر

*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).
*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu](https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   منظمة الحماية الدولية ، [دليل الحماية الجديد للمدافعين عن حقوق الإنسان](https://www.protectioninternational.org/en/node/1106).
*   الإصلاح الجنائي الدولي / رابطة منع التعذيب ، [النساء المحتجزات: دليل للمراقبة الحساسة للنوع الاجتماعي](https://www.apt.ch/content/files_res/thematic-paper-2_women-in-detention-en.pdf)) ، الطبعة الثانية ، 2015.

### قراءة متعمقة

*   الإصلاح الجنائي الدولي ، [الدليل المختصر لقواعد نيلسون مانديلا (القواعد القياسية المنقحة الدنيا)] من (https://www.penalreform.org/resource/short-guide-to-the-nelson-mandela-rules/) في 2016.
*   المنتدى الأوروبي المشترك بين الوكالات المعني بالأمن ، [الأسرة أولاً: الاتصال والدعم خلال الأزمات](https://www.eisf.eu/wp-content/uploads/2013/02/1141-Davidson-2013-Family-First-Liaison-and-Support-During-a-Crisis-2.pdf)، فبراير 2013.
*   المنتدى الأمني المشترك بين الوكالات الأوروبي ، [Security Incident Information Management (SIIM) Handbook]من(https://www.eisf.eu/library/security-incident-information-management-handbook/) في 14 سبتمبر 2017.