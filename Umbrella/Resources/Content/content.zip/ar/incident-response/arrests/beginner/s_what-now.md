---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرف على ما يجب فعله إذا تم القبض على أحد أعضاء فريقك في [عمليات الاعتقال المتقدمة](umbrella://incident-response/arrests/advanced).

### الدروس ذات الصلة / الأدوات

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [تحضير](umbrella://travel/preparation)
*   [الاحتجاجات](umbrella://work/protests/advanced)
* [الاعتداء الجنسي](umbrella://incident-response/sexual-assault)

### مصادر

*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).
*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu](https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   منظمة الحماية الدولية ، [دليل الحماية الجديد للمدافعين عن حقوق الإنسان](https://www.protectioninternational.org/en/node/1106).
*   الإصلاح الجنائي الدولي / رابطة منع التعذيب ، [النساء المحتجزات: دليل للمراقبة الحساسة للنوع الاجتماعي](https://www.apt.ch/content/files_res/thematic-paper-2_women-in-detention-en.pdf) ، الطبعة الثانية ، 2015.