---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرف على ما قبل الإخلاء ، والإخلاء ، والعودة في [الإخلاء المتقدم](umbrella://incident-response/evacuation/advanced). 

### الدروس ذات الصلة / الأدوات

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [النسخ الإحتياطي](umbrella://information/backing-up)
*   [حذف بأمان](umbrella://information/safely-deleting)
*   [درس الاجهاد](umbrella://travel/protective-equipment)
*   [ضغط عصبى](umbrella://stress/stress)

### قراءة متعمقة

*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu]من (https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).