---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرّف على تخطيط الإخلاء وتنبيهاته في [مبتدئ الإخلاء](umbrella://incident-response/evacuation/beginner). 

### الدروس ذات الصلة / الأدوات

*   [النسخ الإحتياطي](umbrella://information/backing-up)
*   [حذف بأمان](umbrella://information/safely-deleting)
*   [اجهزةحماية](umbrella://travel/protective-equipment)
*   [ضغط عصبى](umbrella://stress/stress)

### قراءة متعمقة

*   ECHO ، دليل الأمن العام للمنظمات الإنسانية ، متاح على [eisf.eu](https://www.eisf.eu/library/generic-security-guide-for-humanitarian-organisations/).
*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).