---
index: 8
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعلم كيفية منع الاعتداء الجنسي في [المبتدئين في الاعتداء الجنسي](umbrella://incident-response/sexual-assault/beginner).

تعرّف على ما يجب فعله إذا تعرض أحد أعضاء الفريق للاعتداء الجنسي في [خبير الاعتداء الجنسي](umbrella://incident-response/sexual-assault/expert).

### الدروس ذات الصلة / الأدوات

*   [الحدود](umbrella://travel/borders)
*   [الاخلاء](umbrella://incident-response/evacuation)
*   [مركبة](umbrella://travel/vehicles)
*   [يجري متابعتها](umbrella://work/being-followed)
*   [خطف](umbrella://incident-response/kidnapping/beginner)
*   [الاعتداء على الانترنت](umbrella://communications/online-abuse)

### مصادر

*   لجنة احتجاج الصحفيين ، [دليل أمن الصحفي](https://cpj.org/reports/2012/04/journalist-security-guide.php).
*   شبكة الممارسات الإنسانية ، [مراجعة الممارسة الجيدة رقم 8: إدارة الأمن التشغيلي في البيئات العنيفة (المراجعة المنقحة)](http://odihpn.org/wp-content/uploads/2010/11/GPR_8_revised2.pdf).

### قراءة متعمقة

*   Headington Institute, [Key Messages on Sexual Assault](https://www.headington-institute.org/files/wem--sexual-assault-v1_24675.pdf) by Shannon Mouillesseaux, UNHCR, 2013.
*   فورج مشروع المتحولين جنسيا العنف الجنسي ، ["دليل المساعدة الذاتية للشفاء والتفاهم ،"](https://forge-forward.org/wp-content/docs/self-help-guide-to-healing-2015-FINAL.pdf) سبتمبر 2015.