---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

تعلم ما يجب القيام به خلال هجوم إرهابي في [الإرهاب المتقدم](umbrella://incident-response/terrorism/advanced)

### دروس / أدوات ذات صلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [حماية مساحة العمل الخاصة بك](umbrella://information/protect-your-workspace) 
*   [يجري متابعتها](umbrella://work/being-followed/beginner)
*   [الاتصالات العامة](umbrella://work/public-communications)