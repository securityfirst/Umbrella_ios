---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

تعلم كيفية تقييم مخاطر terrorist attacks في [Terrorism beginner] من (umbrella://incident-response/terrorism/beginner)

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [حماية مساحة العمل الخاصة بك](umbrella://information/protect-your-workspace) 
*   [يجري متابعتها](umbrella://work/being-followed/beginner)
*   [الاتصالات العامة](umbrella://work/public-communications)