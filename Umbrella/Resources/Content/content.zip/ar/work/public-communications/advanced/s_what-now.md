---
index: 7
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعلم كيفية تطوير العلاقات مع مختلف أصحاب المصلحة في [Public Communications مبتدئ](umbrella://work/public-communications/beginner). 

#### ** الدروس ذات الصلة **

* [الخداع](umbrella://communications/phishing/beginner)
* [كلمات السر](umbrella://information/passwords)
* [حماية مساحة العمل الخاصة بك](umbrella://information/protect-your-workspace)
* [ضغط](umbrella://stress/stress/beginner)
* [إساءة على الانترنت](umbrella://communications/online-abuse)
* [رقابة](umbrella://communications/censorship/beginner)
* [الغارات في مكان العمل](umbrella://information/protect-your-workspace)
* [الاخلاء](umbrella://incident-response/evacuation)

### مصادر

* InterAction ، [مجموعة أدوات التضليل](https://www.interaction.org/project/disinformation-toolkit/overview) ، يونيو 2018.

### قراءة متعمقة

* InterAction ، [مشروع معا](https://www.interaction.org/project/together-project/overview).
* ICFJ ، [دليل موجز لتاريخ "الأخبار المزيفة" والتضليل: وحدة تعليمية جديدة لـ ICFJ] من (https://www.icfj.org/news/short-guide-history-fake-news-and-disinformation-new-icfj-learning-module)في  23 يوليو 2018.
* فرونت لاين ديفندرز ، [مضايقة قضائية](https://www.frontlinedefenders.org/en/violation/judicial-harassment). 
* سيمونز وسمونز لواء السلام الدولي ، "التعامل مع مزاعم التشهير" في [مجموعة أدوات المدافعين عن حقوق الإنسان](http://www.elexica.com/en/legal-topics/dispute-resolution-commercial/120618-human-rights-defenders-toolbox)، يونيو 2018.