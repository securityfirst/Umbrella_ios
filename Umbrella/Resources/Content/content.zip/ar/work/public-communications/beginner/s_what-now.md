---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [الاعتداء على الانترنت](umbrella://communications/online-abuse)
*   [قم بحماية مساحة العمل الخاصة بك](umbrella://information/protect-your-workspace)