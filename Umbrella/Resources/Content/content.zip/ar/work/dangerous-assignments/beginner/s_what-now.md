---
index: 4
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرّف على حضور مسرح الجريمة في[Dangerous Assignments Advanced] من (umbrella://work/dangerous-assignments/advanced).

### الدروس ذات الصلة / الأدوات

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [تحضير](umbrella://travel/preparation)
*   [الهواتف المحمولة](umbrella://communications/mobile-phones)
*   [المركبات](umbrella://travel/vehicles)
*   [راديو و هواتف تعمل بالاقمار الصناعية](umbrella://communications/radios-and-satellite-phones)