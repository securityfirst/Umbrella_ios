---
index: 4
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

### الدروس ذات الصلة / الأدوات

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [يجري متابعتها](umbrella://work/being-followed/beginner)
*   [خطف](umbrella://incident-response/kidnapping/beginner)