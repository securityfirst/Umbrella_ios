---
index: 10
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرّف على المراقبة المضادة في المواقع الثابتة في [Being Followed للمبتدئين](umbrella://work/being-followed/beginner).

تعرّف على المراقبة المضادة في مركبة في [يجري اتباع خبير](umbrella://work/being-followed/expert).

### الدروس ذات الصلة

*   [اجتماعات](umbrella://work/meetings)
*   [المركبات](umbrella://travel/vehicles)
*   [الحدود](umbrella://travel/borders)