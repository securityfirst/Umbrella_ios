---
index: 7
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرّف على المراقبة المضادة في المواقع الثابتة في [Being Followed للمبتدئين](umbrella://work/being-followed/beginner).

تعرّف على المراقبة المضادة على الأقدام في [يجري المتابعة المتقدمة](umbrella://work/being-followed/advanced).

### الدروس ذات الصلة / الأدوات

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [اجتماعات](umbrella://work/meetings)
*   [المركبات](umbrella://travel/vehicles)
*   [ادارة المعلومات](umbrella://information/managing-information)
*   [الهواتف المحمولة](umbrella://communications/mobile-phones/beginner)