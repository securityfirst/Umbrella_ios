---
index: 5
title: فى الاحتجاج
---
# فى الاحتجاج

## استخدام أدوات آمنة

*   ** للتواصل: **

قد يكون إنفاذ القانون مراقبة الاتصالات. قم بتشفير رسائلك باستخدام [Android] من (umbrella://tools/messagging/s_signal-for-android.md) أو  [iOS] من (umbrella://tools/messagging/s_signal-for-ios.md).) 

حتى إذا كانت رسائلك مشفرة ، فإن أي هاتف تستخدمه سيبث موقعك والبيانات الوصفية الأخرى التي تكشف عن من تتحدث معه وإلى متى.

(تعرف على [إرسال رسالة](umbrella://communications/sending-a-message).) 

*   ** لمشاركة الصور ومقاطع الفيديو: **

حماية الخصوصية على وسائل التواصل الاجتماعي. طمس الوجوه باستخدام [ObscuraCam](umbrella://tools/messagging/s_obscuracam.md) والشريط (أو الاحتفاظ بأمان) بكشف البيانات الأولية من الصور باستخدام [CameraV]من (https://guardianproject.info/apps/camerav/).

(تعرف على [الخصوصية عبر الإنترنت](umbrella://communications/online-privacy/beginner).)