---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرف على مشاهدة الاحتجاجات في[protests beginner]من (umbrella://work/protests/beginner).

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [الهواتف المحمولة](umbrella://communications/mobile-phones)
*   [ارسال رسالة](umbrella://communications/sending-a-message)
*   [اجراء مكالمة](umbrella://communications/making-a-call)

### أدلة الأدوات ذات الصلة

*   [Signal for Android] من (umbrella://tools/messagging/s_signal-for-android.md) 
*   [Signal لـ iOS](umbrella://tools/messagging/s_signal-for-ios.md)
*   [ObscuraCam](umbrella://tools/messagging/s_obscuracam.md)

### مصادر

*   EFF - حضور الاحتجاجات  [United States]من (https://ssd.eff.org/en/module/attending-protests-united-states) و [International] من (https://ssd.eff.org/en/module/attending-protests-international)
*   EFF — في [Digital Security Tips for Protesters] من (https://www.eff.org/deeplinks/2016/11/digital-security-tips-for-protesters)

### قراءة متعمقة

*   مكتب المؤسسات الديمقراطية وحقوق الإنسان التابع لمنظمة الأمن والتعاون في أوروبا ، [Guidelines on Freedom of Peaceful Assembly] من (https://www.osce.org/odihr/73405?download=true)، الإصدار الثاني ، 2010.