---
index: 4
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

تعرف على المشاركة في الاحتجاجات في [الاحتجاجات المتقدمة](umbrella://work/protests/advanced).

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [درس الاجهاد](umbrella://travel/protective-equipment)