---
index: 3
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

تعرف على كيفية إنشاء كلمة مرور قوية في [Passwords Beginner]من (umbrella://information/passwords/beginner).

انتقل إلى الدرس المتقدم للحصول على المشورة حول كيفية إدارة كلمات المرور الخاصة بك.
[انتقل الى الدرس المتقدم](umbrella://information/passwords/advanced)

### دروس / أدوات ذات صلة

*   [درس حماية الملفات](umbrella://information/protecting-files)
*   [درس التحضير](umbrella://travel/preparation) 

### قراءة متعمقة

*   EFF ، [الخصوصية الرقمية على الحدود الأمريكية: حماية البيانات على أجهزتك](https://www.eff.org/wp/digital-privacy-us-border-2017)