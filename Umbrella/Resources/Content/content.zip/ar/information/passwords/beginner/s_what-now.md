---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

تعرف على كيفية إدارة كلمات المرور الخاصة بك في [كلمات المرور المتقدمة.](umbrella://information/passwords/advanced)

تعرّف على ما يجب فعله إذا كنت مضطرًا إلى تسليم كلمة مرورك في [Passwords Expert.](umbrella://information/passwords/expert)

### قراءة متعمقة

* الأمان أولاً ، [تأمين كلمات المرور وتشفير البيانات](https://advocacyassembly.org/en/courses/31/#/chapter/1/lesson/1)، وهو تدريب مجاني عبر الإنترنت في جمعية المناصرة.