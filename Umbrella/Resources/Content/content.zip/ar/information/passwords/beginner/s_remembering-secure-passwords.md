---
index: 3
title: تذكر كلمات المرور الآمنة
---
## ستساعدك بعض الحيل في إنشاء كلمات مرور يسهل تذكرها ولكن يصعب تخمينها.

*   ** تباين بين الأحرف الكبيرة: ** 'my naME ليس MR. MarSter "

*   ** تبديل الأرقام والحروف: ** 'a11 w0Rk 4nD N0 p14Y'

*   ** دمج الرموز: ** 'c @ t (heR1nthery3'

*   ** استخدم لغات متعددة: ** "Let Them Eat 1e gateaU au ch () colaT"

*   ** استخدم لغات متعددة ، مثل: ** 'Let Them Eat 1e gateaU au ch () colaT'

(تعرف على قواعد بيانات كلمة المرور الآمنة مثل [KeePassXC] من (umbrella://tools/encryption/s_keepassxc.md) في [كلمات المرور المتقدمة](umbrella://information/passwords/advanced).