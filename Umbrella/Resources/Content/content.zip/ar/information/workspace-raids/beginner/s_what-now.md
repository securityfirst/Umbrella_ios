---
index: 5
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)
*   [Protect your Workspace] من (umbrella://information/protect-your-workspace) 
*   [النسخ الإحتياطي](umbrella://information/backing-up)
*   [معدات الحماية](umbrella://information/safely-deleting)
*   [حماية الملفات](umbrella://information/protecting-files)