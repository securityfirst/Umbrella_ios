---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

يخبركم [Workspace Beginner] من (umbrella://information/protect-your-workspace/beginner) بكيفية تقييم بيئة عملك والتخطيط للدفاع عنها.

يخبرك [خبير مساحة العمل](umbrella://information/protect-your-workspace/expert))  بكيفية حماية أجهزتك من التهديدات المادية.

### مصادر

* Security in a Box، [Protect Your Information from Physical Threats](https://securityinabox.org/en/guide/physical/)، updated 28 June 2018.