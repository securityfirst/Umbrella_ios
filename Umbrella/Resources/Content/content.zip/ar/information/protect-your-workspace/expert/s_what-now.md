---
index: 3
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

يوضح [مساحة العمل المتقدمة](umbrella://information/protect-your-workspace/advanced) كيفية حماية المعلومات من المتطفلين.

يخبرك [Workspace Expert] في (umbrella://information/protect-your-workspace/expert) بكيفية حماية أجهزتك من التهديدات المادية.

### مصادر

* Security in a Box  [يحمي معلوماتك من التهديدات المادية] 
(https://securityinabox.org/en/guide/physical/) وآخر تحديث له في 28/06/2018

### لقراءة المزيد

- Tactical Tech، [دليل الأمن الشامل](https://holistic-security.tacticaltech.org) ([pdf](https://holistic-security.tacticaltech.org/downloads.html)); [دليل المدربين الشامل](https://holistic-security.tacticaltech.org/trainers-manual.html) ([pdf](https://holistic-security.tacticaltech.org/ckeditor_assets/attachments/60/holisticsecurity_trainersmanual.pdf)).