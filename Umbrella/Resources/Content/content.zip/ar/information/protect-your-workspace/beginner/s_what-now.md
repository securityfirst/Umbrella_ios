---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

يخبرك [Workspace Advanced](umbrella://information/protect-your-workspace/advanced) بكيفية حماية المعلومات من المتسللين.

يخبرك [Workspace Expert] من (umbrella://information/protect-your-workspace/expert) بكيفية حماية أجهزتك من التهديدات المادية.

### الدروس ذات الصلة

*   [التخطيط الأمني](umbrella://assess-your-risk/security-planning)

### مصادر

* Security in a Box، [حماية معلوماتك من التهديدات المادية](https://securityinabox.org/en/guide/physical/) ، تم تحديثه في 28 يونيو 2018.

### قراءة متعمقة

- المدافعين عن خط المواجهة، ، [Workbook on Security] من (https://www.frontlinedefenders.org/en/resource-publication/workbook-security-practical-steps-human-rights-defenders-risk).