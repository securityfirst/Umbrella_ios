---
index: 9
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

### دروس/أدوات ذات صلة

*   [حماية الملفات](umbrella://information/protecting-files)
*   [حذف بأمان](umbrella://information/safely-deleting)
*   [فيراكربت VeraCrypt](umbrella://tools/files/s_veracrypt.md)
*   [كوبيان النسخ الاحتياطي](umbrella://tools/files/s_cobian-backup.md)
*   [Recuva](umbrella://tools/files/s_recuva.md)

### قراءة متعمقة

*   Security in a Box ، [حماية الملفات الحساسة على جهاز الكمبيوتر الخاص بك](https://securityinabox.org/en/guide/secure-file-storage/).