---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

### دروس / أدوات ذات صلة

*   [حماية الملفات](umbrella://information/protecting-files)

### قراءة متعمقة

*   EFF ، Surveillance Self-Defence ، كيفية حذف بياناتك على [Linux] من (https://ssd.eff.org/en/module/how-delete-your-data-securely-linux) ، أو [Mac OS]من  (https) : //ssd.eff.org/en/module/how-delete-your-data-securely-mac-os-x) و [Windows] من (https://ssd.eff.org/en/module/how-delete-your-data-securely-windows).
*   Security in a Box، [تدمير المعلومات الحساسة](https://securityinabox.org/en/guide/destroy-sensitive-information/).