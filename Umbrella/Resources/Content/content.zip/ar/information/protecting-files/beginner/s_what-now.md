---
index: 7
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

تعرف على كيفية تشفير الملفات في  [Protecting Files Advanced] من (umbrella://information/protecting-files/advanced).)

### الدروس ذات الصلة / الأدوات

*   [النسخ الإحتياطي](umbrella://information/backing-up)
*   [كلمات السر](umbrella://information/passwords)
*   [الهواتف المحمولة](umbrella://communications/mobile-phones/beginner)
*   [برامج ضارة](umbrella://information/malware)
*   [الإنترنت المستوى المتقدم](umbrella://communications/the-internet/advanced)
*   Tor لـ [Windows] من (umbrella://tools/tor/s_tor-for-windows.md) ، و  [Mac]من (umbrella://tools/tor/s_tor-for-mac-os-x.md)، [Linux]من (umbrella://tools/tor/s_tor-for-linux.md)
*   [تشفير اي فون الخاص بك](umbrella://tools/encryption/s_encrypt-your-iphone.md)
*   [اعداد الامن الاساسى لنظام اندرويد](umbrella://tools/other/s_android.md)

### مصادر

*   EFF ، الدفاع عن النفس للأمان ، [الحفاظ على بياناتك آمنة](https://ssd.eff.org/en/module/keeping-your-data-safe) ، آخر مرة تم استعراضها في 2 نوفمبر 2018.