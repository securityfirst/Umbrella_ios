---
index: 6
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

### دروس / أدوات ذات صلة

*   [ادارة المعلومات](umbrella://information/managing-information)
*   [برنامج احتيالي](umbrella://information/malware)
*   [كلمات المرور](umbrella://information/passwords/beginner)
*   [VeraCrypt](umbrella://tools/files/s_veracrypt.md)

### قراءة متعمقة

*   الأمان أولاً ، [تأمين كلمات المرور وتشفير البيانات](https://advocacyassembly.org/en/courses/31/#/chapter/1/lesson/1) ، وهو تدريب مجاني عبر الإنترنت في جمعية Advocacy.
*   EFF، المراقبة الذاتية للدفاع ، [التشفير](https://ssd.eff.org/en/module/what-encryption)
*   Global Partners Digital، [خريطة العالم لقوانين وسياسات التشفير](https://www.gp-digital.org/world-map-of-encryption/)