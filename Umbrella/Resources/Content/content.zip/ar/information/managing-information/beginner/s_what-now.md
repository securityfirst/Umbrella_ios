---
index: 4
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس

### الدروس ذات الصلة

*   [الحذف بأمان ](umbrella://information/safely-deleting)

### قراءة متعمقة

*   EFF ، مراقبة الدفاع عن النفس ، ["تقييم مخاطرك"](https://ssd.eff.org/en/module/assessing-your-risks)