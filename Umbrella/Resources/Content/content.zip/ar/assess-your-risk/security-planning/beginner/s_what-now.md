---
index: 10
title: ماذا الان؟
---
مرر سريعًا لليمين للحصول على قائمة مراجعة هذا الدرس.

### الدروس ذات الصلة / الأدوات

*   [إدارة المعلومات](umbrella://information/managing-information)
*   [إعداد السفر](umbrella://information/backing-up)
*   [حماية مساحة العمل الخاصة بك](umbrella://information/protect-your-workspace)
*   [النسخ الإحتياطي](umbrella://information/backing-up)
*   [الاخلاء](umbrella://incident-response/evacuation)
*   [القبض](umbrella://incident-response/arrests)
*   [خطف](umbrella://incident-response/kidnapping)
*   [الاعتداء الجنسي](umbrella://incident-response/sexual-assault)

### مصادر

* Frontline Defenders، [كتاب عن الأمن: خطوات عملية للمدافعين عن حقوق الإنسان المعرضين للخطر](https://www.frontlinedefenders.org/en/resource-publication/workbook-security-practical-steps-human-rights-defenders-risk) ، 23 يونيو 2016.
*  الحماية الدولية ، [دليل الحماية الجديد للمدافعين عن حقوق الإنسان](https://www.protectioninternational.org/en/node/1106).