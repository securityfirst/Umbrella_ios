---
index: 89
title: Pidgin
---
# Pidgin

أداة مراسلة فورية FOSS تدعم مكوّن تشفير يسمى خارج التسجيل (OTR)