---
index: 26
title: Cryptonite
---

** Cryptonite **: تطبيق FOSS لتشفير الملفات على هواتف Android الذكية.