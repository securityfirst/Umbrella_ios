---
index: 46
title: GNU/Linux
---
# GNU/Linux

نظام تشغيل FOSS يوفر بديلاً لـ مايكروسوفت ويندوز