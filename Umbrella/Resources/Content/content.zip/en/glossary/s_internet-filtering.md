---
index: 53
title: Internet filtering
---
# Internet filtering

Filtering is the politer term for blocking or censoring Internet traffic.