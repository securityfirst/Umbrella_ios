---
index: 23
title: Cookie
---
# Cookie

A small file, saved on your computer by your browser, that can be used to store information for, or identify you to, a particular website