---
index: 118
title: Throwaway address
---
# Throwaway address

An email address you use once, and never again. Used to sign up to Internet services without revealing an email address connected to your identity.