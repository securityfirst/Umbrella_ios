---
index: 59
title: Java Applications (Applets)
---
# Java Applications (Applets)

 Small programs that can run under many operating systems and are cross-platform. They are frequently used to provide improved functionalities within web pages.