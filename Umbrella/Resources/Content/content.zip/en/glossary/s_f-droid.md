---
index: 36
title: F-Droid
---
# F-Droid

An alternative repository from which many FOSS Android applications can be found and downloaded.