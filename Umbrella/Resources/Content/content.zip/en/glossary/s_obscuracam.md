---
index: 77
title: Obscuracam
---
# Obscuracam

A FOSS app for Android smartphones, which protects identity of people by facilitating editions such as face blurring to photographs.