---
index: 66
title: Keyring
---
# Keyring

If you use public key cryptography, you'll need to keep track of many keys: your secret, private key, your public key, and the public keys of everyone you communicate with. The collection of these keys is often referred to as your key ring.