---
index: 3
title: Air gap
---
# Air gap

A computer or network that is physically isolated from all other networks, including the Internet, is said to be air-gapped.