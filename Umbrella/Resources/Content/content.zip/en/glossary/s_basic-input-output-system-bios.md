---
index: 10
title: Basic Input/Output System (BIOS)
---
# Basic Input/Output System (BIOS)

The first and deepest level of software on a computer. The BIOS allows you to set many advanced preferences related to the computer's hardware, including a start-up password