---
index: 57
title: Internet Service Provider (ISP)
---
# Internet Service Provider (ISP)

The company or organisation that provides your initial link to the Internet. The governments of many countries exert control over the Internet, using means such as filtering and surveillance, through the ISPs that operate in those countries.