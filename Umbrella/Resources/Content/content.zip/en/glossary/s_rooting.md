---
index: 97
title: Rooting
---
# Rooting

The process of unlocking features on an Android Phone which are otherwise blocked by the manufacturer or mobile carrier in order to gain full access to the operating system.