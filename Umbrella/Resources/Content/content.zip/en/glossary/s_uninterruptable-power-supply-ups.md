---
index: 124
title: Uninterruptable Power Supply (UPS)
---
# Uninterruptable Power Supply (UPS)

A piece of equipment that allows your critical computing hardware to continue operating, or to shut down gracefully, in the event of a brief loss of power