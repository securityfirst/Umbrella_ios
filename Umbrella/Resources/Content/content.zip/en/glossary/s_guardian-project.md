---
index: 48
title: Guardian Project
---
# Guardian Project

An organisation that creates smartphone apps, mobile devices operating system enhancements and customisations with privacy and security in mind.