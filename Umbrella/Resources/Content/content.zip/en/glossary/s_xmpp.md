---
index: 134
title: XMPP
---
# XMPP

An open standard for instant messages. Corporate services like WhatsApp have their own, closed and secret protocol.