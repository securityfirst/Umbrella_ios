---
index: 99
title: Secure password database
---
# Secure password database

A tool that can encrypt and store your passwords using a single master password