---
index: 119
title: Tor
---
# Tor

An anonymity tool that allows you to bypass Internet censorship and hide the websites and Internet services you visit from anyone who may be monitoring your Internet connection, while also disguising your own location from those websites