---
index: 88
title: Physical threat<
---
# Physical threat

In this context, any threat to your sensitive information that results from other people having direct physical access your computer hardware or from other physical risks, such as breakage, accidents or natural disasters