---
index: 100
title: Secure Sockets Layer (SSL)
---
# Secure Sockets Layer (SSL)

The technology that permits you to maintain a secure, encrypted connection between your computer and some of the websites and Internet services that you visit. When you are connected to a website through SSL, the address of the website will begin with HTTPS rather than HTTP.