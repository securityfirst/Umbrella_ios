---
index: 16
title: Burner phone
---
# Burner phone

A phone that is not connected to your identity, is only used for a small set of calls or activities, and can be discarded if and when it is suspected of being tracked or compromised. Burner phones are often pre-paid mobile phones bought with cash.