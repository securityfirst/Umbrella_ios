---
index: 58
title: Infrared Data Association (IrDA)
---
# Infrared Data Association (IrDA)

A physical wireless communications standard for the short-range exchange of data using infrared spectrum light. IrDA is replaced by Bluetooth in modern devices.