---
index: 56
title: Internet Protocol address (IP address)
---
# Internet Protocol address (IP address)

A unique identifier assigned to your computer when it is connected to the Internet