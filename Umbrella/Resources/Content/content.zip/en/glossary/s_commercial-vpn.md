---
index: 21
title: Commercial VPN
---
# Commercial VPN

A commercial Virtual Private Network is a private service that offers to securely relay your Internet communications via their own network. The advantage of this is that all of the data you send and receive is hidden from local networks, so it is safer from nearby criminals, or untrusted local ISPs or cybercafés. A VPN may be hosted in a foreign country, which is useful both for protecting communications from a local government, and bypassing national censorship. The down side is that most of the traffic is decrypted at the commercial VPN 's end. That means you need to trust the commercial VPN (and the country where it is located) not to snoop on your traffic.