---
index: 11
title: BlackBerry
---
# BlackBerry

A brand of smartphones which run the BlackBerry operating system developed by Research In Motion (RIM).