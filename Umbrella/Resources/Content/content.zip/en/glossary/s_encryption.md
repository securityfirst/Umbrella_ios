---
index: 32
title: Encryption
---
# Encryption

A way of using clever mathematics to encrypt, or scramble, information so that it can only be decrypted and read by someone who has a particular piece of information, such as a password or an encryption key