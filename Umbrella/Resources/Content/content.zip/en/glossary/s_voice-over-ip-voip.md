---
index: 128
title: Voice over IP (VoIP)
---
# Voice over IP (VoIP)

The technology that allows you to use the Internet for voice communication with other VoIP users and telephones