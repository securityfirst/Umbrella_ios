---
index: 25
title: Cryptography
---
# Cryptography

The art of designing secret codes or ciphers that let you send and receive messages to a recipient without others being able to understand the message.