---
index: 123
title: Undelete Plus
---
# Undelete Plus

A freeware tool that can sometimes restore information that you may have deleted accidentally