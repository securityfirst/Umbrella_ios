---
index: 19
title: Cobian Backup
---
# Cobian Backup

A FOSS backup tool. The most recent version of Cobian is closed-source freeware, but prior versions are released as FOSS.