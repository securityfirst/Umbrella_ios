---
index: 92
title: Protocol
---
# Protocol

A communications protocol is a way of sending data between programs or computers. Software programs that use the same protocol can talk to each other: so web browsers and web servers speak the same protocol, called "http". Some protocols use encryption to protect their contents. The secure version of the http protocol is called "https ". Another example of an encrypted protocol used by many different programs is OTR  (Off-the-Record), a protocol for secure instant messaging.