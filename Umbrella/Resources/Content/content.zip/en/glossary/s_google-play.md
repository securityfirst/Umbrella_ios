---
index: 45
title: Google Play
---
# Google Play

The default repository from which Android applications can be found and downloaded.