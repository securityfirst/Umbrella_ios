---
index: 55
title: iPhone
---
# iPhone

A brand of smartphones designed by Apple that run the Apple's iOS operating system.