---
index: 73
title: Master password
---
# Master password

A password used to unlock a store of other passwords or other ways to unlock programs or messages. You should make a master password as strong as you can.