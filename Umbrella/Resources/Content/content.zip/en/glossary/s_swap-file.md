---
index: 113
title: Swap file
---
# Swap file

A file on your computer to which information, some of which may be sensitive, is occasionally saved in order to improve performance