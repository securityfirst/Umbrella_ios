---
index: 78
title: Off-the-Record (OTR)
---
# Off-the-Record (OTR)

Instant messaging systems are often unencrypted. OTR is a way of adding encryption to them, so that you can keep using familiar networks like Facebook Messenger, Google Hangouts, or Microsoft Messenger, but with your messages more resistant to surveillance.