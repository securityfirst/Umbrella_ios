---
index: 103
title: Security policy
---
# Security policy

A written document that describes how your organization can best protect itself from various threats, including a list of steps to be taken should certain security-related events take place