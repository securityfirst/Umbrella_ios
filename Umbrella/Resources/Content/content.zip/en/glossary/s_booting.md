---
index: 15
title: Booting
---
# Booting

The act of starting up a computer