---
index: 31
title: EDGE, GPRS, UMTS
---
# EDGE, GPRS, UMTS

Enhanced Data Rates for GSM Evolution, General Packet Radio Service, and Universal Mobile Telecommunications System - technologies which allow mobile devices to connect to the internet.