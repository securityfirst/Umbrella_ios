---
index: 61
title: K9 Mail
---
# K9 Mail

A FOSS e-mail client for Android smartphones, which enables OpenPGP encryption when used with the Open Keychain app.