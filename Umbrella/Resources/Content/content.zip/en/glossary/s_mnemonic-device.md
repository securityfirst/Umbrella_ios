---
index: 75
title: Mnemonic device
---
# Mnemonic device

A simple trick that can help you remember complex passwords