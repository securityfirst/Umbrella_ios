---
index: 17
title: CD Burner
---
# CD Burner

A computer CD-ROM drive that can write data on blank CDs. DVD burners can do the same with blank DVDs. CD-RW *and *DVD-RW drives can delete and rewrite information more than once on the same CD-RW or DVD-RW disc.