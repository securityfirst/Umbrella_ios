---
index: 86
title: Password manager
---
# Password manager

A tool that can encrypt and store your passwords using a single master password making it practical to use many different passwords on different sites and services without having to memorize them.