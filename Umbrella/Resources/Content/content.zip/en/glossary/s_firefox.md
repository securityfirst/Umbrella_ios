---
index: 39
title: Firefox
---
# Firefox

A popular FOSS Web browser that provides an alternative to Microsoft Internet Explorer