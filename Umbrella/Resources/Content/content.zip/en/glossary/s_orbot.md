---
index: 81
title: Orbot
---
# Orbot

A FOSS app for Android smartphones that enables apps such as Orfox to connect to the Tor network.