---
index: 9
title: Attack
---
# Attack

In computer security, an attack is a method that can be used to compromise security, or its actual use. An attacker is the person or organization using an attack. An attack method is sometimes called an "exploit."