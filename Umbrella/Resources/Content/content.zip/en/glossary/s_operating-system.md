---
index: 80
title: Operating system
---
# Operating system

A program that runs all the other programs on a computer. Windows, Android and Mac OS and iOS by Apple are all examples of operating systems.