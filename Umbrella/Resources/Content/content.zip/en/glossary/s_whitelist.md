---
index: 131
title: Whitelist
---
# Whitelist

A list of websites or Internet services to which some form of access is permitted, when other sites are automatically blocked