---
index: 126
title: VeraCrypt
---
# VeraCrypt

A FOSS file encryption tool that allows you to store sensitive information securely