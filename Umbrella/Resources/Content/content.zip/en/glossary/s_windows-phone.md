---
index: 132
title: Windows Phone
---
# Windows Phone

A smartphone operating system developed by Microsoft.