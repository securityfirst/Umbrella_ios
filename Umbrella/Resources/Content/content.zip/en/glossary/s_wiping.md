---
index: 133
title: Wiping
---
# Wiping

The process of deleting information securely and permanently