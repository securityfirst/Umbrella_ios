---
index: 129
title: Web browser
---
# Web browser

The program you use to view web sites. Firefox, Safari, Internet Explorer and Chrome are all web browsers. Smartphones have a built-in web browser app for the same purpose