---
index: 114
title: Terminal
---
# Terminal

In ancient computer history, a terminal was a dedicated system of keyboard and screen that connected a user to a server. These days, it's more likely to be a program that allows you to talk to computers (either local or remote) over the command line.