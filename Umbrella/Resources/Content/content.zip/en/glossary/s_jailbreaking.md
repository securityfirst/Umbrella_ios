---
index: 60
title: Jailbreaking
---
# Jailbreaking

The process of unlocking features on an iPhone, which are otherwise blocked, by the manufacturer or mobile carrier in order to gain full access to the operating system.