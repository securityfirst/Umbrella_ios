---
index: 30
title: Domain name
---
# Domain name

The address, in words, of a website or Internet service; for example: www.google.com