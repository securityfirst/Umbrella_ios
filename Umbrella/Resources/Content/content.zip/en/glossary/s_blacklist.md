---
index: 12
title: Blacklist
---
# Blacklist

A list of blocked websites and other Internet services that can not be accessed due to a restrictive filtering policy