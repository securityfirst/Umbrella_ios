---
index: 115
title: Thunderbird
---
# Thunderbird

A FOSS email program with a number of security features, including support for the Enigmail encryption add-on