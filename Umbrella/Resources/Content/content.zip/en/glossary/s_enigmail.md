---
index: 35
title: Enigmail
---
# Enigmail

An add-on for the Thunderbird email program that allows it to send and receive encrypted and digitally signed email