---
index: 29
title: Distributed Denial of Service attack (DDoS)
---
# Distributed Denial of Service attack (DDoS)

A method for taking a website or other Internet service offline, by co-ordinating many different computers to request or send data to it simultaneously. Usually the computers used to conduct such an attack are remotely controlled by criminals, who have taken over the machines by breaking into them, or infecting them with malware.