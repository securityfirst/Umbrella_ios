---
index: 38
title: File Transfer Protocol (FTP server)
---
# File Transfer Protocol (FTP server)

An old method for copying files from a local computer to a remote one, or vice versa. The job of FTP programs (and the FTP servers that stored the files) has mostly been replaced by web browsers and web servers, or file synchronising programs like Dropbox.