---
index: 112
title: Steganography
---

**Steganography**: Any method of disguising sensitive information so that it appears to be something else, in order to avoid drawing unwanted attention to it