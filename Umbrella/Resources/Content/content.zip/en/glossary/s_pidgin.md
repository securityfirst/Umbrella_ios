---
index: 89
title: Pidgin
---
# Pidgin

A FOSS instant messaging tool that supports an encryption plugin called Off the Record (OTR)