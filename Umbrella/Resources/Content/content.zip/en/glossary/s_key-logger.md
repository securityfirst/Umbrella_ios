---
index: 63
title: Key logger
---
# Key logger

A type of spyware that records which keys you have typed on your computer's keyboard and send this information to a third party. Key loggers are frequently used to steal email and other passwords.