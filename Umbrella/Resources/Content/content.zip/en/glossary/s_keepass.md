---
index: 65
title: KeePassXC
---
# KeePassXC

A free, open source, cross platform secure password manager