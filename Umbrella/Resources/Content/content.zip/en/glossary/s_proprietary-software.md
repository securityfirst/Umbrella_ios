---
index: 91
title: Proprietary software
---
# Proprietary software

The opposite of Free and Open-Source Software (FOSS). These applications are usually commercial, but can also be freeware with restrictive license requirements.