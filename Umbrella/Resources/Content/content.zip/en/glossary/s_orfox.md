---
index: 82
title: Orfox
---
# Orfox

A FOSS web browser for Android smartphones which, when used in conjunction with Orbot, facilitates browsing over the Tor network.