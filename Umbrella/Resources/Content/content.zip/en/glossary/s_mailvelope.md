---
index: 70
title: Mailvelope
---
# Mailvelope


Mailvelope is a free and open source browser extension that allows you to send and receive encrypted email text and attachments when using webmail services. It relies on the same form of public key encryption as GnuPG and PGP.