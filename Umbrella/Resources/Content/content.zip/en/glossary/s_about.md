---
index: 1
title: About
---
Some of the technical terms that you will encounter, as you read through Umbrella's lessons, are defined below: