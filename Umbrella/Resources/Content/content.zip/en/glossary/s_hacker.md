---
index: 49
title: Hacker
---
# Hacker

In this context, a malicious computer criminal who may be trying to access your sensitive information or take control of your computer remotely