---
index: 14
title: Bluetooth
---
# Bluetooth

A physical wireless communications standard for exchanging data over short distances from fixed and mobile devices. Bluetooth uses short wavelength radio transmissions.