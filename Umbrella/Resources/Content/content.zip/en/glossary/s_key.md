---
index: 62
title: Key
---
# Key

In cryptography, a piece of data which gives you the capability to encrypt or decrypt a message.