---
index: 26
title: Cryptonite
---

**Cryptonite**: A FOSS app for file encryption on Android smartphones.