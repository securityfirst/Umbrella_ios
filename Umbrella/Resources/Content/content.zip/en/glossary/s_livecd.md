---
index: 69
title: LiveCD
---
# LiveCD

A CD that allows your computer to run a different operating system temporarily.