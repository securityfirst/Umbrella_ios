---
index: 47
title: Global Positioning System (GPS)
---
# Global Positioning System (GPS)

A space-based global navigation satellite system that provides location and time information in all weather, anywhere on or near the Earth, where there is an (almost) unobstructed sky view.