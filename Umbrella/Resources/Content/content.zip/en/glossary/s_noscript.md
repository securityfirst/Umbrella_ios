---
index: 76
title: NoScript
---
# NoScript

A security add-on for the Firefox browser that protects you from malicious programs that might be present in unfamiliar webpages