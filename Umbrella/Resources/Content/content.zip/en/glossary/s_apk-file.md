---
index: 6
title: .apk file
---
# .apk file

The file extension used for Android apps.