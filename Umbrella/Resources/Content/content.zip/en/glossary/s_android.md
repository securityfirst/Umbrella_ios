---
index: 4
title: Android
---
# Android

A Linux-based open-source operating system for smartphones and tablet devices, developed by Google.