---
index: 28
title: Digital signature
---
# Digital signature

A way of using encryption to prove that a particular file or message was truly sent by the person who claims to have sent it