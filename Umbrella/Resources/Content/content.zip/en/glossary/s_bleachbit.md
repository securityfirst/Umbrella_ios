---
index: 13
title: BleachBit
---
# BleachBit

A tool that securely and permanently deletes information from your computer or removable storage device.