---
index: 85
title: Passphrase
---
# Passphrase

A passphrase is a kind of password. We use "passphrase" to convey the idea that a password that is a single word is far too short to protect you and a longer phrase 58 much better.