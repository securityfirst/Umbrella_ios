---
index: 18
title: Circumvention
---
# Circumvention

The act of bypassing Internet filters to access blocked websites and other Internet services