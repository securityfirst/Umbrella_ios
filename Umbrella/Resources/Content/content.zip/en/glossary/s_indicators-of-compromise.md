---
index: 52
title: Indicators of compromise
---
# Indicators of compromise

Clues that show that your device may have been broken into or tampered with.