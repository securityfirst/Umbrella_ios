---
index: 108
title: SMTP settings
---
# SMTP settings

SMTP is one method for sending mail between computers. You can configure most email programs to encrypt messages between your e-mail software and the email server by changing your programs' SMTP settings  (as long as your email service supports it)