---
index: 40
title: Firewall
---
# Firewall

A tool that protects your computer from untrusted connections to or from local networks and the Internet