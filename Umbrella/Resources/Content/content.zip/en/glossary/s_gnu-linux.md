---
index: 46
title: GNU/Linux
---
# GNU/Linux

A FOSS operating system that provides an alternative to Microsoft Windows