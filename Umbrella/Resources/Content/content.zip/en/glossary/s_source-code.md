---
index: 111
title: Source code
---
# Source code

The underlying code, written by computer programmers, that allows software to be created. The source code for a given tool will reveal how it works and whether it may be insecure or malicious.