---
index: 51
title: IMAP settings
---
# IMAP settings

IMAP is the way that many email programs communicates with services that send, receive and store your email. By changing the IMAP settings on your email program, you can choose to load email from different servers or set the level of security and encryption used to transfer the mail across the Internet to you.