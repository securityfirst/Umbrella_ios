---
index: 7
title: App Store
---
# App Store

The default repository from which iPhone applications can be found and downloaded.