---
index: 84
title: Passive adversary
---
# Passive adversary

A passive adversary is one that can listen to your communications, but cannot directly tamper with them.