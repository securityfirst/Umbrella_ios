---
index: 37
title: File system
---
# File system

Where data is stored, usually locally, on your computer or other device. File systems are usually where personal documents and notes are stored for easy access.