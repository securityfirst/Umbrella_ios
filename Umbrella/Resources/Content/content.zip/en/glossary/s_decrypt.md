---
index: 27
title: Decrypt
---
# Decrypt

Make a secret message or data intelligible. The idea behind encryption is to make messages that can only be decrypted by the person or people who are meant to receive them.