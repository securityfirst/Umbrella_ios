---
index: 42
title: Free and Open Source Software (FOSS)
---
# Free and Open Source Software (FOSS)

This family of software is available free of charge and has no legal restrictions to prevent a user from testing, sharing or modifying it