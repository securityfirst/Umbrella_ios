---
index: 121
title: Transport encryption
---
# Transport encryption

Encrypting data as it travels across the network, so that others spying on the network cannot read it.