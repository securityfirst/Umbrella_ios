---
index: 43
title: Freeware
---
# Freeware

Includes software that is free of charge but subject to legal or technical restrictions that prevent users from accessing the source code used to create it