---
index: 22
title: Comodo Firewall
---
# Comodo Firewall

A freeware firewall tool