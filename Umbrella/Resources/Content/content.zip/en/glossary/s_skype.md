---
index: 107
title: Skype
---
# Skype

A freeware Voice over IP (VoIP) tool that allows you to speak with other Skype users for free and to call telephones for a fee. The company that maintains Skype claims that conversations with other Skype users are encrypted. Because it is a closed-source tool, there is no way to verify this claim, but many people believe it to be true. Skype also supports instant messaging.