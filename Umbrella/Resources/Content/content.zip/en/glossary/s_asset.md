---
index: 8
title: Asset
---
# Asset

In threat modelling, any piece of data or a device that needs to be protected.