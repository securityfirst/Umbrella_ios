---
index: 1
title: Different stakeholders
---
If you work to advance respect for human rights in your community or country, your main counterparts are: 

* Local authorities;
* The media; 
* The public. 

These actors often play a crucial role in shaping your work and your safety. Identifying strategies to cooperate with them is crucial to security.

*Note: assess what possible threats the people you work with may face from these actors before deciding which strategies in this lesson suit your needs.*