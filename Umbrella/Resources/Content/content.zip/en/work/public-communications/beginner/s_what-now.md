---
index: 5
title: What Now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Online Abuse](umbrella://communications/online-abuse)
*   [Protect your Workspace](umbrella://information/protect-your-workspace)