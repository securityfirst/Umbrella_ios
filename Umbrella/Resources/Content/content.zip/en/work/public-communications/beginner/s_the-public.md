---
index: 4
title: The Public
---
- Make language in advocacy campaigns plain and easy to understand. 

- Tailor your communications to relevant groups (e.g. consider
using humour or references to sport);

- Engage directly (e.g. organize short local seminars for people to make
them understand what HRDs do and what human rights are);

- Highlight cases that are important to the community so that they feel closer to these issues;

- Remind people that you do not defend terrorists;

- Consider providing services needed by the community (e.g. after school classes for street
children or health care center for poor people);

- Maintain blogs or other media products to attract public attention.