---
index: 4
title: What now?
---
Swipe right for this lesson's checklist.

Learn about counter-surveillance on foot in [Being Followed advanced](umbrella://work/being-followed/advanced).

Learn about counter-surveillance in a vehicle in [Being Followed expert](umbrella://work/being-followed/expert).