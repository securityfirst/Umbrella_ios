---
index: 5
title: Identify the Trigger
---
### The trigger is a member of the surveillance team who alerts others when the target is on the move.

The trigger is: 

*	The easiest member of the team to identify.
*	Unlikely to move, which may draw attention to themselves.

## Possible locations for the trigger

*	Inside or outside a fixed location you are visiting. 

*	Somewhere they can wait for a long time without suspicion until you leave. 

*	Several people may spread out act as possible triggers if your exit point is unknown. 

Think like an adversary:

*	Where would you wait as a trigger?