---
index: 10
title: What now?
---
Swipe right for this lesson's checklist.

Learn about counter-surveillance in fixed locations in [Being Followed beginner](umbrella://work/being-followed/beginner).

Learn about counter-surveillance in a vehicle in [Being Followed expert](umbrella://work/being-followed/expert).

### RELATED LESSONS

*   [Meetings](umbrella://work/meetings)
*	[Vehicles](umbrella://travel/vehicles)
*	[Borders](umbrella://travel/borders)