---
index: 1
title: Surveillance on Foot
---
Counter-surveillance is the process of detecting and mitigating hostile surveillance. 

(Learn more about this in [Being Followed beginner](umbrella://work/being-followed/beginner).) 

This lesson involves surveillance on foot.

[Being Followed expert](umbrella://work/being-followed/expert) involves surveillance in a vehicle.

![image](surveillance2.png)