---
index: 6
title: Identify the eyeball
---
The eyeball is whoever is watching you at the time. 

## Don't look over your shoulder 

Create natural opportunities to look around and behind you.

*   Look through windows or admire views;
*	Look at reflections in windows or car mirrors;
*   Cross a busy street and see who follows you;
*   Stop to look at posters or bus timetables, use an ATM, or buy something from a street vendor;
*	If in a team, spread out.