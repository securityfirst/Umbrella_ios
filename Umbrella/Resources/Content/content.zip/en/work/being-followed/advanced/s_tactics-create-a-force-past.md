---
index: 7
title: Create a force-past
---
Create a situation that forces anyone following you to pass you or expose their position. 

## Possible force-past points

### Outdoors

*   Street crossings;
*   Bus stops;
*   Corners (stop or enter a building immediately after turning);
*   Buildings (enter through one entrance, then exit rapidly via another).

### Indoors

*   Escalators;
*   Lifts (go up, let other passengers leave, then immediately go down again. Exit via a back door or car park);
*	Doors (hold them open to let others overtake you).