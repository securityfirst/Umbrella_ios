---
index: 3
title: What to do
---
# Be discreet 

**Remember your first goal is to find out whether you are being followed, not to lose them.**

# Take action 

1.	**Change your plans (safe, recommended)** 


2.	**Lose the surveillance covertly** 


3.	**Lose the surveillance overtly (risky)** 

# Use the 5 counter-surveillance rules 

(Learn more about this in [Being Followed advanced](umbrella://work/being-followed/advanced).)