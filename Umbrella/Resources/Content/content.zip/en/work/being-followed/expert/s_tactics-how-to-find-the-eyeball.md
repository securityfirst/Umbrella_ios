---
index: 4
title: Identify the eyeball
---
### The eyeball is whoever is watching you at the time. 

(Learn more about this in [Being Followed advanced](umbrella://work/being-followed/advanced).)

## If safe to do so while driving:

### Create natural opportunities to look for repeat sightings of a person or vehicle.

*   Use your mirrors;

*   Drive faster or slower;

*	Change lanes;

*   Indicate or change lanes as if to turn, but don't actually turn;

*	Make a U-turn;

*	Turn into a dead end;

*	Drive onto a motorway or highway, then take the next exit;

*	Exit a motorway or highway, then turn back onto it again;

*	If in a team, spread out.

### Create natural opportunities to stop unexpectedly.

*   Fill the tank;

*	Take a phone call;

*   Stop immediately after taking a turn to force others to overtake.

*Only create opportunities to evade surveillance if absolutely vital.*