---
index: 7
title: What now?
---
Swipe right for this lesson's checklist.

Learn about counter-surveillance in fixed locations in [Being Followed beginner](umbrella://work/being-followed/beginner).

Learn about counter-surveillance on foot in [Being Followed advanced](umbrella://work/being-followed/advanced).

### RELATED LESSONS/TOOLS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Meetings](umbrella://work/meetings)
*	[Vehicles](umbrella://travel/vehicles)
*	[Managing Information](umbrella://information/managing-information)
*	[Mobile Phones](umbrella://communications/mobile-phones/beginner)