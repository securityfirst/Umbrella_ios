---
index: 1
title: Surveillance in Vehicles
---
Counter-surveillance is the process of detecting and mitigating hostile surveillance. 

(Learn more about this in [Being Followed beginner](umbrella://work/being-followed/beginner).) 

This lesson involves surveillance in vehicles.

[Being Followed](umbrella://work/being-followed/advanced) involves surveillance on foot.
![image](surveillance4.png)