---
index: 4
title: Ripple
---
# Ripple

[Ripple](https://play.google.com/store/apps/details?id=info.guardianproject.ripple&hl=en) is a free, open-source Android app that tells other apps what to do in an emergency.  

For example, Umbrella will turn into a calculator if you trigger Ripple, so that no-one can access your security advice, forms, and checklists. (Shake your phone to unmask it.)

If you know your device is about to be seized, tap the Ripple icon to trigger other, integrated apps to change their behaviour. 

![image](ripple0.png)

Ripple will tell you which of your apps it can trigger.   

![image](ripple1.png)

_Ripple is in BETA, or testing mode._