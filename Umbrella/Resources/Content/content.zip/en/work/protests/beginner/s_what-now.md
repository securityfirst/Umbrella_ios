---
index: 4
title: What now?
---
Swipe right for this lesson's checklist.

Learn about participating in protests in [Protests Advanced](umbrella://work/protests/advanced).

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Protective Equipment](umbrella://travel/protective-equipment)