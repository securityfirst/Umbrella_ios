---
index: 3
title: Violence
---
Violence in a crowd situation can include: 

*	Harassment or assault;
*	Use of weapons, debris, petrol bombs, fire, pepper spray or tear gas. 

## Withdraw to a safe area

Crowds can turn very quickly. Trust your instinct.  

*	If you sense it is becoming unsafe or you are getting too much attention.

*   If you encounter direct aggression or weapons.

*Reaching for items on the ground may be dangerous, or make you look like you are participating in violence.* 

## Protective clothing

*	Natural fibres are less likely to catch fire than synthetic fibres. 

*	Safety glasses, gas masks, or a wet towel over your nose and mouth can help protect your face from tear gas. Contact lenses and lotion may make the effects of tear gas worse. 

*   Protective vests and caps are available in riot kits.  

*Avoid masks or equipment that make you look like police.*

(Learn more about this in [protective equipment](umbrella://travel/protective-equipment).)