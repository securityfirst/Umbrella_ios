---
index: 2
title: Crushes
---
Crowds pressing together in a crush can be dangerous, even to bystanders. 

A police charge, or an unpredictable crowd, can easily cause a crush during a protest.  

## Avoid a crush

### Stay together

*   Go in a team; 
*   Ensure good communication channels;
*	Ensure everyone's location is known at all times.

### Watch from afar

*	Find a safe vantage point, such as an upstairs window (seek permission).
*	Stand to the side of the protest. Avoid the middle. 

### Prepare a getaway

*   Park vehicles in an accessible location for easy departure. 
*	Plan emergency escape routes and meeting points.
*	Stay alert to crowd behaviour.
*	Withdraw to a safe area if the crowd becomes unpredictable.