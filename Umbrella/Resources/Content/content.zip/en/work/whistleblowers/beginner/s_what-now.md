---
index: 5
title: What Now?
---
Swipe right for this lesson's checklist.

Learn about protecting sources and whistleblowers in [Whistleblowers advanced](umbrella://work/whistleblowers/advanced).

### RELATED LESSONS

* [Security Planning](umbrella://assess-your-risk/security-planning)
* [Managing Information](umbrella://information/managing-information/beginner)
* [Protecting Files](umbrella://information/protecting-files)
* [Online Privacy](umbrella://communications/online-privacy/advanced)
* [Sending a Message](umbrella://communications/sending-a-message)
* [Email](umbrella://communications/email)