---
index: 1
title: What is whistleblowing?
---
A whistleblower reports information about wrongdoing that affects their community because they want to improve the situation. 

This may involve leaking internal documents, recordings, or other evidence.    

Whistleblowers may pass this information to someone in authority with the power to make change, or publicise the information to create public pressure that will result in change.  

This lesson tells you how to assess your risk and protect yourself if you choose to become a whistleblower. 

Learn about protecting sources and whistleblowers in [Whistleblowers advanced](umbrella://work/whistleblowers/advanced).