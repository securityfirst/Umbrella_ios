---
index: 3
title: What to avoid
---
## WHAT NOT TO DO

* Don't go to a crime scene alone.
* Don't arrive before authorities have secured the scene.
* Don't challenge officials charged with securing or investigating the scene or ignore official instructions to gain access.
* Don't come closer than allowed to the crime scene. You may contaminate evidence.