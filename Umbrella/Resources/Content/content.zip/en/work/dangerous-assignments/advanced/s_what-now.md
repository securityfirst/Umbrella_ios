---
index: 4
title: What Now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS/TOOLS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Being Followed](umbrella://work/being-followed/beginner)
*   [Kidnapping](umbrella://incident-response/kidnapping/beginner)