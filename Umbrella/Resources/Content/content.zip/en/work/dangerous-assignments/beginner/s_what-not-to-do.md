---
index: 3
title: What not to do
---
* Don't go alone to a place with no communication.
* Don't go to a remote area without information.