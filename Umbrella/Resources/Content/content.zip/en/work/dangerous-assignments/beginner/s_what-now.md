---
index: 4
title: What Now?
---
Swipe right for this lesson's checklist.

Learn about attending a crime scene in [Dangerous Assignments Advanced](umbrella://work/dangerous-assignments/advanced).

### RELATED LESSONS/TOOLS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Preparation](umbrella://travel/preparation)
*   [Mobile Phones](umbrella://communications/mobile-phones)
*   [Vehicles](umbrella://travel/vehicles)
*   [Radio and Satellite Phones](umbrella://communications/radios-and-satellite-phones)