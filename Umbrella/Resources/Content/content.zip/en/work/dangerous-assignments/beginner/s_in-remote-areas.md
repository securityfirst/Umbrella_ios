---
index: 1
title: Remote areas
---
This lesson describes how to stay safe in remote areas, especially as a journalist.

On occasion, journalistic work will take you to remote places in rural communities or mountainous areas with little infrastructure and no communication networks.