---
index: 8
title: What now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Being Followed](umbrella://work/being-followed/beginner)
*   [Mobile Phones](umbrella://communications/mobile-phones)
*   [Email](umbrella://communications/email)
*	[Vehicles](umbrella://travel/vehicles)
*	[Borders](umbrella://travel/borders)