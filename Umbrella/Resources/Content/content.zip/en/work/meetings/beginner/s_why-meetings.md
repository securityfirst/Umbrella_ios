---
index: 1
title: Risks
---
Meetings may: 

*	Expose the identity of participants;
*	Expose the work of participants;
*	Trigger a serious incident like kidnap or arrest. 

(Learn more about [kidnapping](umbrella://incident-response/kidnapping/beginner) and [arrest](umbrella://incident-response/arrests).) 
 
It is vital to plan and prepare sensitive meetings with people at risk.