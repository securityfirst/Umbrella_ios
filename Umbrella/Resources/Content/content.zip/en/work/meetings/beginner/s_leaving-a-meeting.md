---
index: 7
title: Leaving a Meeting
---
*	Let others leave first and monitor for surveillance.  
*	Wait about ten minutes before you leave. 

If collaborating, your team member should wait for a further ten minutes to check that you are clean.