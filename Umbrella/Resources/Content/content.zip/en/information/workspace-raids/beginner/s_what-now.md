---
index: 5
title: What now?
---
Swipe right for this lesson's checklist. 

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Protect your Workspace](umbrella://information/protect-your-workspace) 
*   [Backing Up](umbrella://information/backing-up)
*   [Safely Deleting](umbrella://information/safely-deleting)
*   [Protecting Files](umbrella://information/protecting-files)