---
index: 5
title: Backup Software
---
# Cobian Backup 

Cobian Backup is a user-friendly tool that can: 

*	Run automatically;
*	At scheduled intervals; 
*	Include only files that have changed since your last backup; 
*	Compress backups to make them smaller. 

Learn how to install and run [Cobian Backup](umbrella://tools/files/s_cobian-backup.md).