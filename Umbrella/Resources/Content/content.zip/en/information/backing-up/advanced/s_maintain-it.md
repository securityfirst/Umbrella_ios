---
index: 8
title: Maintain it!
---
# Backups are vital.

They may be the most important aspect of data security.

It might sound like a lot of work to implement the policies and use the tools described in this chapter. Don't let that put you off. 

# Take the time.

Setting up a backup strategy does take time at first, but it is well worth the effort.

# Make it easy for yourself to maintain. 

Once you have a system in place, it is much easier to keep going.