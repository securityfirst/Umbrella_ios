---
index: 9
title: What now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS/TOOLS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Protecting Files](umbrella://information/protecting-files)
*   [Safely Deleting](umbrella://information/safely-deleting)
*   [VeraCrypt](umbrella://tools/files/s_veracrypt.md)
*   [Cobian Backup](umbrella://tools/files/s_cobian-backup.md)
*   [Recuva](umbrella://tools/files/s_recuva.md)

### FURTHER READING

*   Security in a Box, [Protect the Sensitive Files on your Computer](https://securityinabox.org/en/guide/secure-file-storage/).