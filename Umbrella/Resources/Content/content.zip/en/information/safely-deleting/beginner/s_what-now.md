---
index: 6
title: What now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS/TOOLS

*   [Protecting Files](umbrella://information/protecting-files)

### FURTHER READING

*   EFF, Surveillance Self-Defense, How to delete your data on [Linux](https://ssd.eff.org/en/module/how-delete-your-data-securely-linux), [Mac OS](https://ssd.eff.org/en/module/how-delete-your-data-securely-mac-os-x), and [Windows](https://ssd.eff.org/en/module/how-delete-your-data-securely-windows). 
*   Security in a Box, [Destroy Sensitive Information](https://securityinabox.org/en/guide/destroy-sensitive-information/).