---
index: 4
title: At your workstation
---
## Good security habits for your desk

- Position your screen to prevent others from reading it. (Account for windows, open doors, visitor waiting areas and other considerations.)

- Consider purchasing privacy filters for your devices. Privacy filters make it difficult to read a screen unless it is directly in front of you. They are available for laptops, external monitors, tablets and smartphones. 

- Paper documents and physical notes on your desk may reveal extremely sensitive information if they are stolen, copied or photographed.

*Paper calendars, planners, journals, address books and sticky notes are refreshingly immune to malware, but they are also impossible to encrypt.*

(Learn more about this in [borders](umbrella://travel/borders).)