---
index: 1
title: Physical intrusion
---
### Malicious individuals may seek to access your sensitive information or to steal the device it is stored on. 

This lesson tells you how to reduce the risk of physical intrusion. 

Build on these steps and adapt them for your own physical security environment.