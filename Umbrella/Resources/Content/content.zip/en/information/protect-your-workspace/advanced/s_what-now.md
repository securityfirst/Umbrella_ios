---
index: 6
title: What now?
---
Swipe right for this lesson's checklist. 

[Workspace Beginner](umbrella://information/protect-your-workspace/beginner) tells you how to assess your work environment and plan to defend it.

[Workspace Expert]((umbrella://information/protect-your-workspace/expert) tells you how to protect your devices from physical threats. 

### SOURCES

* Security in a Box, [Protect your Information from Physical Threats](https://securityinabox.org/en/guide/physical/), updated June 28, 2018.