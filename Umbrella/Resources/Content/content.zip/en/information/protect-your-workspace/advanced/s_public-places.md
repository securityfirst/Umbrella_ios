---
index: 5
title: In public
---
### Few people work exclusively in their home or office. 

## Protect laptops, tablets and phones

- Avoid using devices in public spaces unless you have reason to believe they are safe. 

- Conceal devices when they are not in use, for example, by carrying them in something that does not look like a laptop bag.

- Keep your devices with you at all times when travelling or staying in a hotel. Thieves often exploit meal times and restroom visits to steal unattended equipment.

- Consider travelling with a security cable that you can use to attach devices to a nearby object and deter thieves. 

- Position your screen so that others cannot read it. Buy privacy filters if you work in public often.

- Use a VPN or the Tor Browser whenever you connect to Wi-Fi.

*Other people on the same network have the ability to monitor your Internet activity and read the unencrypted data you send and receive, even when a strong WiFi password has been set.* 

(Learn more about this in [Online Privacy](umbrella://communications/online-privacy/advanced).)