---
index: 6
title: What now?
---
Swipe right for this lesson's checklist.

### RELATED LESSONS/TOOLS

*   [Managing Information](umbrella://information/managing-information)
*   [Malware](umbrella://information/malware)
*	[Passwords](umbrella://information/passwords/beginner)
*   [VeraCrypt](umbrella://tools/files/s_veracrypt.md)

### FURTHER READING

* 	Security First, [Secure Passwords and Encryption of Data](https://advocacyassembly.org/en/courses/31/#/chapter/1/lesson/1), a free online training at Advocacy Assembly.  
*   EFF, Surveillance Self-Defense, [Encryption](https://ssd.eff.org/en/module/what-encryption)
*	Global Partners Digital, [World map of encryption laws and policies](https://www.gp-digital.org/world-map-of-encryption/)