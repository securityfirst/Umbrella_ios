---
index: 6
title: Insecure Devices
---
### A dedicated device for dangerous places or risky operations is an insecure device.

A secure device is kept away from threats. An insecure device is one you prepare specifically for threatening situtations, in order to minimise loss if it is stolen or accessed.  

*Many journalists and activists travel with a basic netbook or burner phone that they can afford to lose.*

*	Keep your regular documents, contacts or email information off the device.
* Isolate certain communications from the rest of your online activity by restricting them to an insecure device.

(Learn more about [Burner Phones](umbrella://communications/mobile-phones/beginner/s_burner-phones.md).)