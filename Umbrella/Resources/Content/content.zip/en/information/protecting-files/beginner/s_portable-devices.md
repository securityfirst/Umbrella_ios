---
index: 1
title: The risks of portable devices
---
If you have a smartphone, laptop, or tablet, you’re probably carrying a massive amount of data with you at all times: 

*	 Social contacts;
*  Passwords and account details;
*  Financial and medical information;
*  Private communications;
*  Personal documents and photos;
*  Confidential information about others.

Your device can be taken from you relatively easily:

*	 Seized at the border;
*  Taken from you in the street;
*  Burgled from your house.  

If someone who takes your device can access your data, they can copy it in seconds. 

In this lesson, learn how to make it harder for anyone who steals your device to access your data.

Learn how to encrypt files using Veracrypt in [Protecting Files Advanced](umbrella://information/protecting-files/advanced).