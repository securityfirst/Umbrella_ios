---
index: 1
title: Kidnap Stages
---
Kidnap strategies are based on:

*	Avoidance;
*	Survival.

A kidnapping has five stages: 

### 1.  Surveillance 

### 2.  Capture

### 3.  Transport (once or several times)

### 4.  Confinement

### 5.  Release or termination

## Avoidance

Kidnapping beginner outlines how to evade surveillance and capture.

## Survival

[Kidnapping advanced](umbrella://incident-response/kidnapping/advanced) outlines survival strategies for capture, transport, confinement and release.

[Kidnapping expert](umbrella://incident-response/kidnapping/expert) outlines incident management when a colleague is kidnapped.