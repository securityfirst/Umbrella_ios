---
index: 1
title: Seek help
---
# If a colleague or staff member is kidnapped

Dealing with the kidnapping of a member of staff is a very sensitive and complex task. 

This lesson provides an overview of recommended actions.

**For detailed advice, see Further Reading at the end of the lesson.**