---
index: 2
title: First Steps
---
**1. Set up a crisis management team in HQ.** 

**2. Appoint a manager to coordinate.** 

_Next steps depend on the circumstances and the manager's assessment of the best course of action._

### Prioritise contacting next of kin.  

Failure to do this quickly can damage the relationship of trust, particularly if news is published first in the media.  

*Lack of trust makes crisis management much harder.*