---
index: 3
title: Transport
---
## Submit to being moved

You may be drugged, blindfolded, restrained or beaten. 

Do not resist. The main purpose is to make you more submissive.  

## During transport

*	Use the time to compose yourself. 
*	Keep your mind active.