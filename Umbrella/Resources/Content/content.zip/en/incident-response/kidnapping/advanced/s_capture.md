---
index: 2
title: Capture
---
# The first 15 - 45 minutes 

This is the most dangerous time.

Kidnappers are likely to:

*	Be under stress;
*	Be armed;
*	Use weapons if you show resistance. 

### Remember, your goal is to survive and regain freedom.

## Cooperate. 

*   Be calm and cooperative; 
*	Speak only when spoken to;
*	Listen carefully and attentively;
*	Avoid sudden moves;
*   Avoid eye contact, which may appear aggressive.

## Accept the situation.

*	Do not be aggressive;
*	Do not physically resist;
*	Do not be a hero;
*   Do not attempt escape;
*	Fear and shock are normal reactions.

## Stay together
*   If in a group, try not to be separated;
*	Appoint a spokesperson based on ability, not rank.