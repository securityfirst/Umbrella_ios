---
index: 5
title: Termination/Release
---
## Release

If released: 

*   Obey all instructions from your abductors.

## Rescue

If rescue is attempted by force:

*	Lie on the floor;
*	Put hands over your head; 
*	Do not try to identify yourself until appropriate to do so.
    
## Escape (last resort only)

Escape may:

*	Create more danger;
*	Endanger the lives of others, if in a group;
*	Frustrate rescue activities. 

_If you are caught you are likely to be held in harsher conditions than before._

Only consider escape if:

*   You are sure it will succeed; 
*	It is imperative in order to save your life.