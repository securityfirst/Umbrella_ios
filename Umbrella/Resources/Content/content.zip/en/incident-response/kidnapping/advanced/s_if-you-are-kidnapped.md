---
index: 1
title: If you are kidnapped
---
# Survive and regain freedom

Your goal is to survive and regain freedom.

Your behaviour can increase the likelihood of achieving this. 

You therefore have some control over the outcome of a kidnapping.

## A kidnapping or hostage situation has five stages. 

(Learn more about this in [kidnapping beginner](umbrella://incident-response/kidnapping/beginner).)

### 1.  Surveillance 

### 2.  Capture

### 3.  Transport (once or several times)

### 4.  Confinement

### 5.  Release/Termination

This lesson outlines survival strategies for capture, transport, confinement and release.

[Kidnapping expert](umbrella://incident-response/kidnapping/expert) offers resources when a colleague is kidnapped.