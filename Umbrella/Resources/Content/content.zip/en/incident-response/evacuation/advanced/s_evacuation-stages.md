---
index: 1
title: Evacuation stages
---
## Evacuation has four stages

### 1.  Planning 

### 2.  Alert

### 3.  Pre-evacuation

### 4.  Evacuation

[Evacuation beginner](umbrella://incident-response/evacuation/beginner) outlines planning and alert.

This lesson outlines pre-evacuation and evacuation.