---
index: 5
title: Return
---
### Return may occur soon after evacuation or take a long time.  

Re-establishing operations after an evacuation can be difficult. 

## Recognise people who stayed

If team members or local people did not evacuate, they may have experienced hardship and threats, and resent those who left.

## Be honest, tactful, and transparent 

Your actions before, during, and after evacuation will help you restore relationships with local people and authorities.