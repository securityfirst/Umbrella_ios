---
index: 1
title: If you are assaulted
---
### Sexual assault is a specific category of threat requiring prevention, mitigation, crisis management and after-care. 

[Sexual assault beginner](umbrella://incident-response/sexual-assault/beginner) outlines prevention. 

This lesson outlines what to do if you are raped or assaulted.

[Sexual assault expert](umbrella://incident-response/sexual-assault/expert) outlines what to do when a team member is raped or assaulted.