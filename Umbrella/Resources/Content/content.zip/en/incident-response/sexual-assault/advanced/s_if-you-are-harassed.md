---
index: 2
title: If you are harassed
---
## Ignore the advance.  

In some cases, this may persuade the harasser to stop.

If you experience harassment online, this may involve blocking abusive accounts.

(Learn more about this in [Online Abuse](umbrella://communications/online-abuse/expert).)

## Confront the harasser.  

*	If you stop and politely ask, “Were you speaking to me?” this may embarrass the harasser into desisting.

*	Tell the harasser directly that you do not like what he/she is doing, preferably in the presence of a witness. 

## Report the harasser.

*	Inform someone you trust.

*	Tell someone in a position of authority. 

* If a manager is harassing you, report them to someone more senior and request protection or counselling if appropriate.  

*  Document your reports and requests. 

*It is understandable if you do not wish to report the harassment, but it is helpful to report it.*

The harasser should be warned, disciplined, or reported to police.