---
index: 5
title: What now?
---
Swipe right for this lesson's checklist. 

Learn what to do during a terrorist attack in [Terrorism advanced](umbrella://incident-response/terrorism/advanced)

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Protect your Workspace](umbrella://information/protect-your-workspace) 
*   [Being Followed](umbrella://work/being-followed/beginner)
*   [Public Communications](umbrella://work/public-communications)