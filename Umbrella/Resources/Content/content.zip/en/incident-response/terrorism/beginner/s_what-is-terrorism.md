---
index: 1
title: What is terrorism?
---
### You may be directly or indirectly affected by terrorist attacks because of where you are or what you do. 

Terrorists use crime and fear to further a political agenda. They create fear in part because they commit criminal acts that are unpredictable but have a severe impact. The security implications may feel daunting.   

However, terrorist attacks generally conform to patterns. Understanding those patterns will help you reduce your risk and strengthen your emergency response.    

### There is no single, one-size-fits-all plan to combat terrorism. 

This lesson provides some questions to help you think through specific scenarios. Security plans for terrorist attacks should be based on your vulnerabilities and updated regularly.  

Learn what to do during a terrorist attack in [Terrorism advanced](umbrella://incident-response/terrorism/advanced).