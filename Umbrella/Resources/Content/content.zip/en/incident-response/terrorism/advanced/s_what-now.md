---
index: 5
title: What now?
---
Swipe right for this lesson's checklist. 

Learn to assess your risk of terrorist attacks in [Terrorism beginner](umbrella://incident-response/terrorism/beginner)

### RELATED LESSONS

*   [Security Planning](umbrella://assess-your-risk/security-planning)
*   [Protect your Workspace](umbrella://information/protect-your-workspace) 
*   [Being Followed](umbrella://work/being-followed/beginner)
*   [Public Communications](umbrella://work/public-communications)