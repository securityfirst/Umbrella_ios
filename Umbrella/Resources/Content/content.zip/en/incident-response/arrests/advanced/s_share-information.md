---
index: 3
title: Share information
---
# Manage communications

## Liaise with family and loved ones. 

*	Tell them what you are doing;
*	Maintain regular, direct communications;
*	Follow what they are doing, and warn them if it may be counter-productive.
  
## Liase with colleagues.

*	Inform other teams and ask advice, if appropriate. 

## Publicise the incident.

*	In many cases, international attention may be enough to pressure the authorities to release the detainee.

(Learn about [emergency support](umbrella://emergency-support).)