---
index: 1
title: Seek information
---
### If a team member is arrested, establish where they are and under whose authority. 

*	Visit all relevant local authorities.
*	Inform the relevant embassy, if appropriate. 
*	Be assertive and persistent. 
  
## Seek legal support 

Engage a good lawyer who:

*	Knows the local language and legal system;
*	Has relevant experience
*	May have useful connections.

Some arrests may be made for legitimate reasons and the team member may have to account for their actions.